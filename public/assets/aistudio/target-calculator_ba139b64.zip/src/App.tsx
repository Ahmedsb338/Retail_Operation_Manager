/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import { 
  RotateCcw, 
  AlertTriangle, 
  CheckCircle2, 
  Share2, 
  Copy, 
  Check, 
  X, 
  ChevronRight, 
  Sun, 
  Moon,
  MessageSquare,
  Send,
  TrendingUp,
  TrendingDown,
  Plus,
  Store,
  Sparkles,
  Layers,
  LayoutGrid,
  Table as TableIcon,
  BarChart3,
  Activity,
  Calendar
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  ReferenceLine
} from 'recharts';

// Data model for each individual product/item
export interface ItemData {
  id: string;
  name: string;
  shortName: string;
  monthlyTarget: string;
  mtdAchievement: string;
  todayAch: string;
}

// Data model for Box Weights (At the top, as requested)
// Acquisition represents full 60% (NOT divided across low, high, cash)
// Terminal represents 10%
// Enterprise represents 10% (covers Acc and GAs)
// ADSL represents 16%
// At Home represents 4%
export interface BoxWeights {
  acq: string;       // 60%
  terminal: string;  // 10%
  enterprise: string;// 10%
  adsl: string;      // 16%
  home: string;      // 4%
}

const DEFAULT_BOX_WEIGHTS: BoxWeights = {
  acq: '60',
  terminal: '10',
  enterprise: '10',
  adsl: '16',
  home: '4',
};

// Default empty items with 0 targets
const DEFAULT_ITEMS: Record<string, ItemData> = {
  // Acquisition Box (3 items)
  acq_low: { id: 'acq_low', name: 'Low Acq', shortName: 'Acq Low', monthlyTarget: '0', mtdAchievement: '0', todayAch: '0' },
  acq_high: { id: 'acq_high', name: 'High Acq', shortName: 'Acq High', monthlyTarget: '0', mtdAchievement: '0', todayAch: '0' },
  vf_cash: { id: 'vf_cash', name: 'Vf Cash', shortName: 'Cash New', monthlyTarget: '0', mtdAchievement: '0', todayAch: '0' },
  
  // Terminal Box
  terminal: { id: 'terminal', name: 'Terminal', shortName: 'Terminal', monthlyTarget: '0', mtdAchievement: '0', todayAch: '0' },

  // Enterprise Box (2 items)
  ent_acc: { id: 'ent_acc', name: 'Ent Acc', shortName: 'Acc', monthlyTarget: '0', mtdAchievement: '0', todayAch: '0' },
  ent_gas: { id: 'ent_gas', name: 'Ent GAs', shortName: 'GAs', monthlyTarget: '0', mtdAchievement: '0', todayAch: '0' },

  // Fixed Box (2 items)
  adsl: { id: 'adsl', name: 'ADSL', shortName: 'ADSL', monthlyTarget: '0', mtdAchievement: '0', todayAch: '0' },
  home: { id: 'home', name: '@Home', shortName: '@Home', monthlyTarget: '0', mtdAchievement: '0', todayAch: '0' },
};

// Realistic Store Test Preset to preview WhatsApp message with accurate numbers
const SAMPLE_TEST_ITEMS: Record<string, ItemData> = {
  acq_low: { id: 'acq_low', name: 'Low Acq', shortName: 'Acq Low', monthlyTarget: '150', mtdAchievement: '45', todayAch: '5' },
  acq_high: { id: 'acq_high', name: 'High Acq', shortName: 'Acq High', monthlyTarget: '80', mtdAchievement: '32', todayAch: '4' },
  vf_cash: { id: 'vf_cash', name: 'Vf Cash', shortName: 'Cash New', monthlyTarget: '100', mtdAchievement: '50', todayAch: '6' },
  terminal: { id: 'terminal', name: 'Terminal', shortName: 'Terminal', monthlyTarget: '60', mtdAchievement: '28', todayAch: '3' },
  ent_acc: { id: 'ent_acc', name: 'Ent Acc', shortName: 'Acc', monthlyTarget: '20', mtdAchievement: '10', todayAch: '1' },
  ent_gas: { id: 'ent_gas', name: 'Ent GAs', shortName: 'GAs', monthlyTarget: '30', mtdAchievement: '12', todayAch: '2' },
  adsl: { id: 'adsl', name: 'ADSL', shortName: 'ADSL', monthlyTarget: '90', mtdAchievement: '42', todayAch: '4' },
  home: { id: 'home', name: '@Home', shortName: '@Home', monthlyTarget: '25', mtdAchievement: '14', todayAch: '1' },
};

export interface TnpsRowData {
  id: string;
  agentName: string;
  detractors: string;
  passive: string;
  promoters: string;
}

const DEFAULT_TNPS_ROWS: TnpsRowData[] = [
  { id: '1', agentName: '', detractors: '0', passive: '0', promoters: '0' },
];

const SAMPLE_TNPS_ROWS: TnpsRowData[] = [
  { id: '1', agentName: 'Store Agent', detractors: '6', passive: '2', promoters: '29' },
];

// Data model for 7-day daily achievement trend chart (Recharts)
export interface DailyTrendPoint {
  id: string;
  date: string;
  dayLabel: string;
  acq: number;
  terminal: number;
  enterprise: number;
  fixed: number;
  total: number;
}

const generateInitial7DayHistory = (): DailyTrendPoint[] => {
  const result: DailyTrendPoint[] = [];
  const now = new Date();
  const dayNames = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

  for (let i = 6; i >= 1; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const dateStr = `${d.getDate()}/${d.getMonth() + 1}`;
    const name = dayNames[d.getDay()];
    // Realistic retail store daily achievements
    const acq = 12 + ((i * 3) % 8);
    const terminal = 2 + (i % 3);
    const enterprise = 2 + ((i + 1) % 3);
    const fixed = 4 + ((i * 2) % 4);
    result.push({
      id: `day-${i}`,
      date: dateStr,
      dayLabel: `${name} ${dateStr}`,
      acq,
      terminal,
      enterprise,
      fixed,
      total: acq + terminal + enterprise + fixed,
    });
  }

  // Day 7: Today
  const todayStr = `${now.getDate()}/${now.getMonth() + 1}`;
  const todayName = dayNames[now.getDay()];
  result.push({
    id: 'today',
    date: todayStr,
    dayLabel: `اليوم (${todayName})`,
    acq: 0,
    terminal: 0,
    enterprise: 0,
    fixed: 0,
    total: 0,
  });

  return result;
};

const DEFAULT_TOTAL_SHIFTS = '25';
const DEFAULT_REMAINING_SHIFTS = '10';
const DEFAULT_STORE_NAME = 'Abo Elmatamir Mahkama St. Store';

export default function App() {
  // 1. Box Weights (Acquisition 60% as a full box, Terminal 10%, Enterprise 10%, ADSL 16%, @Home 4%)
  const [boxWeights, setBoxWeights] = useState<BoxWeights>(() => {
    if (typeof window !== 'undefined' && window.localStorage) {
      const saved = localStorage.getItem('target_calc_box_weights_v5');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {}
      }
    }
    return DEFAULT_BOX_WEIGHTS;
  });

  // 2. Items state (Targets, MTD, Today Ach)
  const [items, setItems] = useState<Record<string, ItemData>>(() => {
    if (typeof window !== 'undefined' && window.localStorage) {
      const saved = localStorage.getItem('target_calc_items_v5');
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (parsed && typeof parsed === 'object') {
            return { ...DEFAULT_ITEMS, ...parsed };
          }
        } catch {}
      }
    }
    return DEFAULT_ITEMS;
  });

  // 3. Shifts & Store info
  const [totalShifts, setTotalShifts] = useState<string>(() => {
    if (typeof window !== 'undefined' && window.localStorage) {
      return localStorage.getItem('target_calc_total_shifts_v5') || DEFAULT_TOTAL_SHIFTS;
    }
    return DEFAULT_TOTAL_SHIFTS;
  });

  const [remainingShifts, setRemainingShifts] = useState<string>(() => {
    if (typeof window !== 'undefined' && window.localStorage) {
      return localStorage.getItem('target_calc_remaining_shifts_v5') || DEFAULT_REMAINING_SHIFTS;
    }
    return DEFAULT_REMAINING_SHIFTS;
  });

  const [storeName, setStoreName] = useState<string>(() => {
    if (typeof window !== 'undefined' && window.localStorage) {
      return localStorage.getItem('target_calc_store_name_v5') || DEFAULT_STORE_NAME;
    }
    return DEFAULT_STORE_NAME;
  });

  const [redSalesToday, setRedSalesToday] = useState<string>(() => {
    if (typeof window !== 'undefined' && window.localStorage) {
      return localStorage.getItem('target_calc_red_today_v5') || '0';
    }
    return '0';
  });

  const [redSalesTarget, setRedSalesTarget] = useState<string>(() => {
    if (typeof window !== 'undefined' && window.localStorage) {
      return localStorage.getItem('target_calc_red_target_v5') || '0';
    }
    return '0';
  });

  // 4. tNPS
  const [tnpsRows, setTnpsRows] = useState<TnpsRowData[]>(() => {
    if (typeof window !== 'undefined' && window.localStorage) {
      const saved = localStorage.getItem('target_calc_tnps_v5');
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) return parsed;
        } catch {}
      }
    }
    return DEFAULT_TNPS_ROWS;
  });

  // UI States
  const [viewMode, setViewMode] = useState<'cards' | 'table'>('cards');
  const [showResetModal, setShowResetModal] = useState<boolean>(false);
  const [showShareModal, setShowShareModal] = useState<boolean>(false);
  const [showWhatsAppModal, setShowWhatsAppModal] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [copiedWhatsApp, setCopiedWhatsApp] = useState<boolean>(false);
  const [saveToast, setSaveToast] = useState<string | null>(null);

  // Daily tracking to preserve daily values for WhatsApp and prevent duplicate MTD additions
  const [lastSavedToday, setLastSavedToday] = useState<Record<string, number>>(() => {
    if (typeof window !== 'undefined' && window.localStorage) {
      const saved = localStorage.getItem('target_calc_last_saved_today_v1');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {}
      }
    }
    return {};
  });

  const [isTodaySaved, setIsTodaySaved] = useState<boolean>(() => {
    if (typeof window !== 'undefined' && window.localStorage) {
      return localStorage.getItem('target_calc_today_saved_v1') === 'true';
    }
    return false;
  });

  // 5. 7-Day Daily Achievements History for Recharts
  const [dailyHistory, setDailyHistory] = useState<DailyTrendPoint[]>(() => {
    if (typeof window !== 'undefined' && window.localStorage) {
      const saved = localStorage.getItem('target_calc_daily_history_v2');
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length >= 7) return parsed;
        } catch {}
      }
    }
    return generateInitial7DayHistory();
  });

  const [chartMode, setChartMode] = useState<'total' | 'breakdown'>('total');

  // Dark Mode with localStorage
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined' && window.localStorage) {
      const saved = localStorage.getItem('target_calc_dark_mode');
      if (saved !== null) return saved === 'true';
      return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  const toggleDarkMode = () => {
    setDarkMode((prev) => {
      const next = !prev;
      if (typeof window !== 'undefined' && window.localStorage) {
        localStorage.setItem('target_calc_dark_mode', String(next));
      }
      return next;
    });
  };

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('target_calc_box_weights_v5', JSON.stringify(boxWeights));
    } catch {}
  }, [boxWeights]);

  useEffect(() => {
    try {
      localStorage.setItem('target_calc_items_v5', JSON.stringify(items));
    } catch {}
  }, [items]);

  useEffect(() => {
    try {
      localStorage.setItem('target_calc_daily_history_v2', JSON.stringify(dailyHistory));
    } catch {}
  }, [dailyHistory]);

  useEffect(() => {
    try {
      localStorage.setItem('target_calc_total_shifts_v5', totalShifts);
      localStorage.setItem('target_calc_remaining_shifts_v5', remainingShifts);
      localStorage.setItem('target_calc_store_name_v5', storeName);
      localStorage.setItem('target_calc_red_today_v5', redSalesToday);
      localStorage.setItem('target_calc_red_target_v5', redSalesTarget);
      localStorage.setItem('target_calc_tnps_v5', JSON.stringify(tnpsRows));
      localStorage.setItem('target_calc_last_saved_today_v1', JSON.stringify(lastSavedToday));
      localStorage.setItem('target_calc_today_saved_v1', String(isTodaySaved));
    } catch {}
  }, [totalShifts, remainingShifts, storeName, redSalesToday, redSalesTarget, tnpsRows, lastSavedToday, isTodaySaved]);

  // Shifts calculations
  const parsedTotalShifts = Math.max(0, parseFloat(totalShifts) || 0);
  const parsedRemainingShifts = Math.max(0, parseFloat(remainingShifts) || 0);
  const elapsedShifts = parsedTotalShifts - parsedRemainingShifts;

  // Helper to parse any numeric weight, converting Arabic-Indic digits if present
  const parseNumericWeight = (val: string | number | undefined | null): number => {
    if (val === undefined || val === null || val === '') return 0;
    if (typeof val === 'number') return isNaN(val) ? 0 : Math.max(0, val);
    const converted = String(val)
      .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 1632))
      .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 1776))
      .replace(/[^0-9.]/g, '');
    const num = parseFloat(converted);
    return isNaN(num) ? 0 : Math.max(0, num);
  };

  // DYNAMIC BOX WEIGHTS CALCULATION:
  // Dynamically uses parsed weights entered by the user so calculations strictly apply edited weights!
  const activeWeights = useMemo(() => {
    const acq = parseNumericWeight(boxWeights.acq);
    const terminal = parseNumericWeight(boxWeights.terminal);
    const enterprise = parseNumericWeight(boxWeights.enterprise);
    const adsl = parseNumericWeight(boxWeights.adsl);
    const home = parseNumericWeight(boxWeights.home);
    const total = acq + terminal + enterprise + adsl + home;
    const divisor = total > 0 ? total : 100;
    return {
      acq,
      terminal,
      enterprise,
      adsl,
      home,
      total,
      divisor,
    };
  }, [boxWeights]);

  const totalBoxWeight = activeWeights.total;
  const isWeightValid = Math.abs(totalBoxWeight - 100) < 0.01;

  // Compute individual item metrics
  const computeItemMetrics = (itemKey: string) => {
    const raw = items[itemKey] || DEFAULT_ITEMS[itemKey];
    const target = parseFloat(raw.monthlyTarget) || 0;
    const mtd = parseFloat(raw.mtdAchievement) || 0;
    const today = parseFloat(raw.todayAch) || 0;

    const remainingTarget = Math.max(0, target - mtd);
    const dailyTarget = parsedRemainingShifts > 0 ? remainingTarget / parsedRemainingShifts : 'N/A';
    const mtdPercent = target > 0 ? (mtd / target) * 100 : 0;

    let projectedUnits: number | 'N/A' = 'N/A';
    let projectionPercent: number | 'N/A' = 'N/A';
    if (elapsedShifts > 0 && parsedTotalShifts > 0) {
      projectedUnits = (mtd / elapsedShifts) * parsedTotalShifts;
      if (target > 0) {
        projectionPercent = (projectedUnits / target) * 100;
      }
    }

    return {
      ...raw,
      parsedTarget: target,
      parsedMtd: mtd,
      parsedToday: today,
      remainingTarget,
      dailyTarget,
      mtdPercent,
      projectedUnits,
      projectionPercent,
    };
  };

  const computedItems = useMemo(() => {
    const result: Record<string, ReturnType<typeof computeItemMetrics>> = {};
    Object.keys(DEFAULT_ITEMS).forEach((k) => {
      result[k] = computeItemMetrics(k);
    });
    return result;
  }, [items, parsedRemainingShifts, elapsedShifts, parsedTotalShifts]);

  // Helper to compute RE % (Realization / Projection Rate):
  // Exact user formula: (MTD ÷ Target) ÷ Elapsed Shifts × Total Shifts × 100
  // Reference from store calculator: (99 ÷ 1,850) ÷ 2 × 30 × 100 = 80.27% -> 80%
  const calculateRE = (mtd: number, target: number): number | 'N/A' => {
    if (target <= 0) return 'N/A';
    if (elapsedShifts > 0 && parsedTotalShifts > 0) {
      return ((mtd / target) / elapsedShifts) * parsedTotalShifts * 100;
    }
    return (mtd / target) * 100;
  };

  // BOX CALCULATIONS:
  // 1. Acquisition Box: 60% weight (includes Low Acq, High Acq, Vf Cash)
  const acqBox = useMemo(() => {
    const low = computedItems.acq_low;
    const high = computedItems.acq_high;
    const cash = computedItems.vf_cash;

    const monthlyTarget = low.parsedTarget + high.parsedTarget + cash.parsedTarget;
    const mtdAchievement = low.parsedMtd + high.parsedMtd + cash.parsedMtd;
    const todayAch = low.parsedToday + high.parsedToday + cash.parsedToday;
    const remainingTarget = Math.max(0, monthlyTarget - mtdAchievement);
    const dailyTarget = parsedRemainingShifts > 0 ? remainingTarget / parsedRemainingShifts : 'N/A';
    const mtdPercent = monthlyTarget > 0 ? (mtdAchievement / monthlyTarget) * 100 : 0;

    let projectedUnits: number | 'N/A' = 'N/A';
    let projectionPercent: number | 'N/A' = 'N/A';
    if (elapsedShifts > 0 && parsedTotalShifts > 0) {
      projectedUnits = (mtdAchievement / elapsedShifts) * parsedTotalShifts;
      if (monthlyTarget > 0) {
        projectionPercent = (projectedUnits / monthlyTarget) * 100;
      }
    }

    const weight = activeWeights.acq;
    const contributionMtd = (mtdPercent * weight) / 100;
    const contributionProj = typeof projectionPercent === 'number' ? (projectionPercent * weight) / 100 : 0;

    return {
      name: 'Acquisition Box',
      weight,
      monthlyTarget,
      mtdAchievement,
      todayAch,
      remainingTarget,
      dailyTarget,
      mtdPercent,
      projectedUnits,
      projectionPercent,
      contributionMtd,
      contributionProj,
      items: [low, high, cash],
    };
  }, [computedItems, activeWeights.acq, parsedRemainingShifts, elapsedShifts, parsedTotalShifts]);

  // 2. Terminal Box
  const terminalBox = useMemo(() => {
    const ter = computedItems.terminal;
    const weight = activeWeights.terminal;
    const contributionMtd = (ter.mtdPercent * weight) / 100;
    const contributionProj = typeof ter.projectionPercent === 'number' ? (ter.projectionPercent * weight) / 100 : 0;

    return {
      name: 'Terminal',
      weight,
      monthlyTarget: ter.parsedTarget,
      mtdAchievement: ter.parsedMtd,
      todayAch: ter.parsedToday,
      remainingTarget: ter.remainingTarget,
      dailyTarget: ter.dailyTarget,
      mtdPercent: ter.mtdPercent,
      projectedUnits: ter.projectedUnits,
      projectionPercent: ter.projectionPercent,
      contributionMtd,
      contributionProj,
      item: ter,
    };
  }, [computedItems.terminal, activeWeights.terminal]);

  // 3. Enterprise Box (includes Ent Acc and Ent GAs)
  const enterpriseBox = useMemo(() => {
    const acc = computedItems.ent_acc;
    const gas = computedItems.ent_gas;

    const monthlyTarget = acc.parsedTarget + gas.parsedTarget;
    const mtdAchievement = acc.parsedMtd + gas.parsedMtd;
    const todayAch = acc.parsedToday + gas.parsedToday;
    const remainingTarget = Math.max(0, monthlyTarget - mtdAchievement);
    const dailyTarget = parsedRemainingShifts > 0 ? remainingTarget / parsedRemainingShifts : 'N/A';
    const mtdPercent = monthlyTarget > 0 ? (mtdAchievement / monthlyTarget) * 100 : 0;

    let projectedUnits: number | 'N/A' = 'N/A';
    let projectionPercent: number | 'N/A' = 'N/A';
    if (elapsedShifts > 0 && parsedTotalShifts > 0) {
      projectedUnits = (mtdAchievement / elapsedShifts) * parsedTotalShifts;
      if (monthlyTarget > 0) {
        projectionPercent = (projectedUnits / monthlyTarget) * 100;
      }
    }

    const weight = activeWeights.enterprise;
    const contributionMtd = (mtdPercent * weight) / 100;
    const contributionProj = typeof projectionPercent === 'number' ? (projectionPercent * weight) / 100 : 0;

    return {
      name: 'Enterprise Box',
      weight,
      monthlyTarget,
      mtdAchievement,
      todayAch,
      remainingTarget,
      dailyTarget,
      mtdPercent,
      projectedUnits,
      projectionPercent,
      contributionMtd,
      contributionProj,
      items: [acc, gas],
    };
  }, [computedItems, activeWeights.enterprise, parsedRemainingShifts, elapsedShifts, parsedTotalShifts]);

  // 4. ADSL Box
  const adslBox = useMemo(() => {
    const adsl = computedItems.adsl;
    const weight = activeWeights.adsl;
    const contributionMtd = (adsl.mtdPercent * weight) / 100;
    const contributionProj = typeof adsl.projectionPercent === 'number' ? (adsl.projectionPercent * weight) / 100 : 0;

    return {
      name: 'ADSL',
      weight,
      monthlyTarget: adsl.parsedTarget,
      mtdAchievement: adsl.parsedMtd,
      todayAch: adsl.parsedToday,
      remainingTarget: adsl.remainingTarget,
      dailyTarget: adsl.dailyTarget,
      mtdPercent: adsl.mtdPercent,
      projectedUnits: adsl.projectedUnits,
      projectionPercent: adsl.projectionPercent,
      contributionMtd,
      contributionProj,
      item: adsl,
    };
  }, [computedItems.adsl, activeWeights.adsl]);

  // 5. At Home Box
  const homeBox = useMemo(() => {
    const home = computedItems.home;
    const weight = activeWeights.home;
    const contributionMtd = (home.mtdPercent * weight) / 100;
    const contributionProj = typeof home.projectionPercent === 'number' ? (home.projectionPercent * weight) / 100 : 0;

    return {
      name: '@Home',
      weight,
      monthlyTarget: home.parsedTarget,
      mtdAchievement: home.parsedMtd,
      todayAch: home.parsedToday,
      remainingTarget: home.remainingTarget,
      dailyTarget: home.dailyTarget,
      mtdPercent: home.mtdPercent,
      projectedUnits: home.projectedUnits,
      projectionPercent: home.projectionPercent,
      contributionMtd,
      contributionProj,
      item: home,
    };
  }, [computedItems.home, activeWeights.home]);

  // Combined Fixed Box (ADSL + @Home - calculated separately per user rules)
  const fixedBox = useMemo(() => {
    const monthlyTarget = adslBox.monthlyTarget + homeBox.monthlyTarget;
    const mtdAchievement = adslBox.mtdAchievement + homeBox.mtdAchievement;
    const todayAch = adslBox.todayAch + homeBox.todayAch;
    const remAdsl = typeof adslBox.remainingTarget === 'number' ? adslBox.remainingTarget : 0;
    const remHome = typeof homeBox.remainingTarget === 'number' ? homeBox.remainingTarget : 0;
    const remainingTarget = remAdsl + remHome;
    const dailyAdsl = typeof adslBox.dailyTarget === 'number' ? adslBox.dailyTarget : 0;
    const dailyHome = typeof homeBox.dailyTarget === 'number' ? homeBox.dailyTarget : 0;
    const dailyTarget = dailyAdsl + dailyHome;
    const mtdPercent = monthlyTarget > 0 ? (mtdAchievement / monthlyTarget) * 100 : 0;

    // Separate individual RE calculations (do NOT lump targets together):
    const adslProj = calculateRE(adslBox.mtdAchievement, adslBox.monthlyTarget);
    const homeProj = calculateRE(homeBox.mtdAchievement, homeBox.monthlyTarget);
    const adslProjVal = typeof adslProj === 'number' ? adslProj : 0;
    const homeProjVal = typeof homeProj === 'number' ? homeProj : 0;

    const wAdsl = activeWeights.adsl;
    const wHome = activeWeights.home;
    const sumFixedWeights = wAdsl + wHome;

    // Weighted projection for Fixed box based on separate calculations:
    const projectionPercent = sumFixedWeights > 0
      ? ((adslProjVal * wAdsl) + (homeProjVal * wHome)) / sumFixedWeights
      : 0;

    // Contribution to store overall (e.g., ADSL RE * 0.16 + @Home RE * 0.04):
    const storeContribution = (adslProjVal * (wAdsl / 100)) + (homeProjVal * (wHome / 100));

    return {
      monthlyTarget,
      mtdAchievement,
      todayAch,
      remainingTarget,
      dailyTarget,
      mtdPercent,
      adslProj,
      homeProj,
      adslProjVal,
      homeProjVal,
      projectionPercent,
      storeContribution,
      wAdsl,
      wHome,
    };
  }, [adslBox, homeBox, activeWeights.adsl, activeWeights.home, elapsedShifts, parsedTotalShifts]);

  // OVERALL MTD % = Normalized weighted average using user-edited weights!
  // Σ (Box MTD % × Edited Box Weight) / Total Active Box Weights
  const overallMtdPercent = useMemo(() => {
    const list = [
      { weight: activeWeights.acq, mtdPercent: acqBox.mtdPercent, target: acqBox.monthlyTarget },
      { weight: activeWeights.terminal, mtdPercent: terminalBox.mtdPercent, target: terminalBox.monthlyTarget },
      { weight: activeWeights.enterprise, mtdPercent: enterpriseBox.mtdPercent, target: enterpriseBox.monthlyTarget },
      { weight: activeWeights.adsl, mtdPercent: adslBox.mtdPercent, target: adslBox.monthlyTarget },
      { weight: activeWeights.home, mtdPercent: homeBox.mtdPercent, target: homeBox.monthlyTarget },
    ];

    const activeBoxesWithTarget = list.filter((b) => b.target > 0);
    if (activeBoxesWithTarget.length === 0) return 0;

    const activeBoxes = activeBoxesWithTarget.some((b) => b.weight > 0)
      ? activeBoxesWithTarget.filter((b) => b.weight > 0)
      : activeBoxesWithTarget;

    const totalActiveWeights = activeBoxes.reduce((sum, b) => sum + b.weight, 0);
    if (totalActiveWeights <= 0) return 0;

    const weightedSum = activeBoxes.reduce((sum, b) => sum + (b.mtdPercent * b.weight), 0);
    return weightedSum / totalActiveWeights;
  }, [
    acqBox.mtdPercent, acqBox.monthlyTarget,
    terminalBox.mtdPercent, terminalBox.monthlyTarget,
    enterpriseBox.mtdPercent, enterpriseBox.monthlyTarget,
    adslBox.mtdPercent, adslBox.monthlyTarget,
    homeBox.mtdPercent, homeBox.monthlyTarget,
    activeWeights
  ]);

  // OVERALL PROJECTION % = Normalized weighted average using user-edited weights!
  // Formula requested by user: Σ (Box Projection % × Edited Box Weight) / Total Active Box Weights
  // Calculates immediately on any weight change or target change across all 5 categories:
  // 1. Acquisition
  // 2. Enterprise
  // 3. Terminal
  // 4. ADSL
  // 5. At Home
  const overallProjectionPercent = useMemo(() => {
    const list = [
      {
        name: 'Acquisition',
        weight: activeWeights.acq,
        mtd: acqBox.mtdAchievement,
        target: acqBox.monthlyTarget,
      },
      {
        name: 'Enterprise',
        weight: activeWeights.enterprise,
        mtd: enterpriseBox.mtdAchievement,
        target: enterpriseBox.monthlyTarget,
      },
      {
        name: 'Terminal',
        weight: activeWeights.terminal,
        mtd: terminalBox.mtdAchievement,
        target: terminalBox.monthlyTarget,
      },
      {
        name: 'ADSL',
        weight: activeWeights.adsl,
        mtd: adslBox.mtdAchievement,
        target: adslBox.monthlyTarget,
      },
      {
        name: 'At Home',
        weight: activeWeights.home,
        mtd: homeBox.mtdAchievement,
        target: homeBox.monthlyTarget,
      },
    ];

    const activeBoxesWithTarget = list.filter((b) => b.target > 0);
    if (activeBoxesWithTarget.length === 0) return 0;

    // Use boxes with targets and edited weights > 0 (if user assigned weights)
    const activeBoxes = activeBoxesWithTarget.some((b) => b.weight > 0)
      ? activeBoxesWithTarget.filter((b) => b.weight > 0)
      : activeBoxesWithTarget;

    const totalActiveWeights = activeBoxes.reduce((sum, b) => sum + b.weight, 0);
    if (totalActiveWeights <= 0) return 0;

    const weightedSum = activeBoxes.reduce((sum, b) => {
      const proj = calculateRE(b.mtd, b.target);
      const projVal = typeof proj === 'number' ? proj : 0;
      return sum + (projVal * b.weight);
    }, 0);

    return weightedSum / totalActiveWeights;
  }, [
    acqBox.mtdAchievement, acqBox.monthlyTarget,
    terminalBox.mtdAchievement, terminalBox.monthlyTarget,
    enterpriseBox.mtdAchievement, enterpriseBox.monthlyTarget,
    adslBox.mtdAchievement, adslBox.monthlyTarget,
    homeBox.mtdAchievement, homeBox.monthlyTarget,
    activeWeights,
    elapsedShifts,
    parsedTotalShifts
  ]);

  // Attach today's real-time achievement numbers to the 7th data point on the trend chart
  const active7DayData = useMemo(() => {
    const todayAcq = acqBox.todayAch;
    const todayTer = terminalBox.todayAch;
    const todayEnt = enterpriseBox.todayAch;
    const todayFix = fixedBox.todayAch;
    const todayTotal = todayAcq + todayTer + todayEnt + todayFix;

    return dailyHistory.map((pt, idx) => {
      if (idx === dailyHistory.length - 1) {
        return {
          ...pt,
          acq: todayAcq > 0 ? todayAcq : pt.acq,
          terminal: todayTer > 0 ? todayTer : pt.terminal,
          enterprise: todayEnt > 0 ? todayEnt : pt.enterprise,
          fixed: todayFix > 0 ? todayFix : pt.fixed,
          total: todayTotal > 0 ? todayTotal : pt.total,
        };
      }
      return pt;
    });
  }, [dailyHistory, acqBox.todayAch, terminalBox.todayAch, enterpriseBox.todayAch, fixedBox.todayAch]);

  // Trend Chart Summary Metrics
  const chartMetrics = useMemo(() => {
    const totalSum = active7DayData.reduce((acc, curr) => acc + curr.total, 0);
    const avgDaily = Math.round(totalSum / (active7DayData.length || 7));
    const peakDay = active7DayData.reduce((max, curr) => curr.total > max.total ? curr : max, active7DayData[0] || { total: 0, dayLabel: '' });
    const todayPoint = active7DayData[active7DayData.length - 1] || { total: 0 };
    return {
      totalSum,
      avgDaily,
      peakTotal: peakDay.total,
      peakLabel: peakDay.dayLabel,
      todayTotal: todayPoint.total,
    };
  }, [active7DayData]);

  // tNPS Calculations
  const computedTnpsRows = useMemo(() => {
    const parsedRemaining = parseFloat(remainingShifts) || 0;
    return tnpsRows.map((row) => {
      const detractors = parseFloat(row.detractors) || 0;
      const passive = parseFloat(row.passive) || 0;
      const promoters = parseFloat(row.promoters) || 0;
      const total = detractors + passive + promoters;

      let tnpsPercent: number = 0;
      if (total > 0) {
        tnpsPercent = ((promoters - detractors) / total) * 100;
      }

      let requiredPromoters = 0;
      if (detractors > 0 || passive > 0 || promoters > 0) {
        const rawReq = (((1.7 * detractors) + (0.7 * passive)) / 0.3) - promoters;
        requiredPromoters = Math.max(0, Math.round(rawReq));
      }

      let daily = 0;
      if (parsedRemaining > 0 && requiredPromoters > 0) {
        daily = Math.round(requiredPromoters / parsedRemaining);
      }

      return {
        ...row,
        parsedDetractors: detractors,
        parsedPassive: passive,
        parsedPromoters: promoters,
        total,
        tnpsPercent,
        requiredPromoters,
        daily,
      };
    });
  }, [tnpsRows, remainingShifts]);

  // Strengths and Weaknesses Analysis based on Projection %
  const analysisInsights = useMemo(() => {
    const strengths: { name: string; proj: number; diff: number }[] = [];
    const weaknesses: { name: string; proj: number; diff: number; neededDaily: number }[] = [];

    // Analyze by Boxes and items
    const checkItem = (name: string, target: number, projVal: number | 'N/A' | string, daily: number | 'N/A' | string) => {
      const parsedProj = typeof projVal === 'number' ? projVal : parseFloat(String(projVal));
      if (target > 0 && !isNaN(parsedProj) && isFinite(parsedProj)) {
        const proj = Math.round(parsedProj);
        if (proj >= 100) {
          strengths.push({ name, proj, diff: proj - 100 });
        } else if (proj < 85) {
          const parsedDaily = typeof daily === 'number' ? daily : parseFloat(String(daily));
          weaknesses.push({ 
            name, 
            proj, 
            diff: 100 - proj, 
            neededDaily: !isNaN(parsedDaily) && isFinite(parsedDaily) ? Math.round(parsedDaily) : 0 
          });
        }
      }
    };

    checkItem('Acquisition Box', acqBox.monthlyTarget, acqBox.projectionPercent, acqBox.dailyTarget);
    checkItem('Terminal', terminalBox.monthlyTarget, terminalBox.projectionPercent, terminalBox.dailyTarget);
    checkItem('Enterprise Box', enterpriseBox.monthlyTarget, enterpriseBox.projectionPercent, enterpriseBox.dailyTarget);
    checkItem('ADSL', adslBox.monthlyTarget, adslBox.projectionPercent, adslBox.dailyTarget);
    checkItem('@Home', homeBox.monthlyTarget, homeBox.projectionPercent, homeBox.dailyTarget);

    strengths.sort((a, b) => b.proj - a.proj);
    weaknesses.sort((a, b) => b.diff - a.diff);

    return { strengths, weaknesses };
  }, [acqBox, terminalBox, enterpriseBox, adslBox, homeBox]);

  // Number formatters - STRICTLY whole integers, no decimals
  const formatNumber = (val: number | 'N/A' | string | undefined | null): string => {
    if (val === 'N/A' || val === undefined || val === null || val === '') return 'N/A';
    const num = typeof val === 'number' ? val : parseFloat(val);
    if (isNaN(num) || !isFinite(num)) return 'N/A';
    return new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 }).format(Math.round(num));
  };

  const formatPercent = (val: number | 'N/A' | string | undefined | null): string => {
    if (val === 'N/A' || val === undefined || val === null || val === '') return 'N/A';
    const num = typeof val === 'number' ? val : parseFloat(val);
    if (isNaN(num) || !isFinite(num)) return 'N/A';
    return `${Math.round(num)}%`;
  };

  const getPercentBadge = (val: number | 'N/A' | string | undefined | null) => {
    if (val === 'N/A' || val === undefined || val === null || val === '') {
      return darkMode ? 'text-slate-400 bg-slate-800' : 'text-slate-500 bg-slate-100';
    }
    const num = typeof val === 'number' ? val : parseFloat(val);
    if (isNaN(num) || !isFinite(num)) {
      return darkMode ? 'text-slate-400 bg-slate-800' : 'text-slate-500 bg-slate-100';
    }
    const rounded = Math.round(num);
    if (rounded >= 100) {
      return darkMode ? 'text-emerald-300 bg-emerald-950/80 border border-emerald-600/50' : 'text-emerald-700 bg-emerald-50 border border-emerald-300';
    }
    if (rounded >= 80) {
      return darkMode ? 'text-amber-300 bg-amber-950/80 border border-amber-600/50' : 'text-amber-700 bg-amber-50 border border-amber-300';
    }
    return darkMode ? 'text-rose-300 bg-rose-950/80 border border-rose-600/50' : 'text-rose-700 bg-rose-50 border border-rose-300';
  };

  const getTodayFormattedDate = () => {
    const now = new Date();
    return `${now.getDate()}/${now.getMonth() + 1}/${now.getFullYear()}`;
  };


  // Simple Daily Achievement Goal Visualizer under each box header
  const BoxDailyGoalVisualizer = ({
    boxLabel,
    todayAch,
    dailyTarget,
    colorTheme = 'teal',
    subChips,
  }: {
    boxLabel: string;
    todayAch: number | string;
    dailyTarget: number | string | undefined | null;
    colorTheme?: 'teal' | 'sky' | 'blue' | 'indigo';
    subChips?: Array<{ label: string; today: number | string; target: number | string | undefined | null }>;
  }) => {
    const todayAchNum = typeof todayAch === 'number' ? todayAch : parseFloat(todayAch || '0') || 0;
    const targetNum = typeof dailyTarget === 'number' ? dailyTarget : (dailyTarget === 'N/A' || !dailyTarget ? 0 : parseFloat(String(dailyTarget)) || 0);
    const hasTarget = targetNum > 0;
    const progressPercent = hasTarget ? (todayAchNum / targetNum) * 100 : (todayAchNum > 0 ? 100 : 0);
    const clampedWidth = Math.min(100, Math.max(0, progressPercent));
    const isGoalMet = hasTarget && todayAchNum >= targetNum;
    const remainingDaily = hasTarget ? Math.max(0, targetNum - todayAchNum) : 0;
    const surplusDaily = hasTarget && todayAchNum > targetNum ? todayAchNum - targetNum : 0;

    const themeConfig = {
      teal: {
        bg: darkMode ? 'bg-teal-950/40 border-teal-500/25' : 'bg-teal-50/80 border-teal-200',
        labelColor: darkMode ? 'text-teal-300' : 'text-teal-900',
        barFill: 'bg-gradient-to-r from-teal-500 to-teal-400',
        trackBorder: darkMode ? 'border-teal-700/50' : 'border-teal-300',
      },
      sky: {
        bg: darkMode ? 'bg-sky-950/40 border-sky-500/25' : 'bg-sky-50/80 border-sky-200',
        labelColor: darkMode ? 'text-sky-300' : 'text-sky-900',
        barFill: 'bg-gradient-to-r from-sky-500 to-sky-400',
        trackBorder: darkMode ? 'border-sky-700/50' : 'border-sky-300',
      },
      blue: {
        bg: darkMode ? 'bg-blue-950/40 border-blue-500/25' : 'bg-blue-50/80 border-blue-200',
        labelColor: darkMode ? 'text-blue-300' : 'text-blue-900',
        barFill: 'bg-gradient-to-r from-blue-500 to-blue-400',
        trackBorder: darkMode ? 'border-blue-700/50' : 'border-blue-300',
      },
      indigo: {
        bg: darkMode ? 'bg-indigo-950/40 border-indigo-500/25' : 'bg-indigo-50/80 border-indigo-200',
        labelColor: darkMode ? 'text-indigo-300' : 'text-indigo-900',
        barFill: 'bg-gradient-to-r from-indigo-500 to-indigo-400',
        trackBorder: darkMode ? 'border-indigo-700/50' : 'border-indigo-300',
      },
    }[colorTheme];

    return (
      <div className={`px-2.5 py-1.5 border-b text-[10px] sm:text-[11px] transition-colors ${themeConfig.bg}`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
          {/* Left / Info: Goal comparison */}
          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
            <div className="flex items-center gap-1">
              <span className="text-[11px]">🎯</span>
              <span className={`font-black text-[9px] sm:text-[10px] uppercase tracking-wider ${themeConfig.labelColor}`}>
                هدف اليوم / Daily Goal:
              </span>
            </div>

            {/* Today achieved vs Calculated Daily target */}
            <div className="flex items-center gap-1 font-mono text-[10px] sm:text-xs">
              <span className="font-black text-blue-700 dark:text-blue-300 px-1 py-0.2 rounded bg-blue-500/10 border border-blue-500/20" title="إنجاز اليوم">
                اليوم: {formatNumber(todayAch)}
              </span>
              <span className="text-slate-400 font-bold">/</span>
              <span className="font-extrabold text-slate-700 dark:text-slate-200 px-1 py-0.2 rounded bg-slate-500/10 border border-slate-500/20" title="تارجت اليوم المحسوب">
                تارجت: {formatNumber(dailyTarget)}
              </span>
            </div>

            {/* Achievement Ratio Badge */}
            <span className={`px-1.5 py-0.2 rounded font-mono font-black text-[9px] border ${
              isGoalMet
                ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-300 border-emerald-500/40 shadow-2xs'
                : progressPercent >= 50
                ? 'bg-amber-500/20 text-amber-700 dark:text-amber-300 border-amber-500/40'
                : 'bg-slate-500/15 text-slate-600 dark:text-slate-400 border-slate-500/30'
            }`}>
              {formatPercent(progressPercent)}
            </span>

            {/* Status note */}
            <span className="text-[9px] font-semibold text-slate-500 dark:text-slate-400">
              {isGoalMet ? (
                <span className="text-emerald-600 dark:text-emerald-400 font-black">
                  ✓ مكتمل {surplusDaily > 0 ? `(+${formatNumber(surplusDaily)})` : ''}
                </span>
              ) : hasTarget ? (
                <span>
                  متبقي: <strong className="font-mono font-black text-amber-600 dark:text-amber-400">{formatNumber(remainingDaily)}</strong>
                </span>
              ) : (
                <span>لا يوجد تارجت متبقي</span>
              )}
            </span>
          </div>

          {/* Right: Small Progress Bar Track */}
          <div className="flex items-center gap-2 self-stretch sm:self-auto">
            {subChips && subChips.length > 0 && (
              <div className="hidden md:flex items-center gap-1 text-[9px] font-mono text-slate-500 dark:text-slate-400">
                {subChips.map((chip) => (
                  <span
                    key={chip.label}
                    className="px-1 py-0.2 rounded bg-black/5 dark:bg-white/5 border border-slate-300/60 dark:border-slate-700/60"
                  >
                    {chip.label}: <strong className="text-blue-600 dark:text-blue-300">{formatNumber(chip.today)}</strong>/<span className="text-slate-600 dark:text-slate-300">{formatNumber(chip.target)}</span>
                  </span>
                ))}
              </div>
            )}

            <div className="flex-1 sm:w-36 md:w-44 flex items-center gap-1.5">
              <div className={`flex-1 h-2 bg-slate-200/90 dark:bg-slate-900/90 rounded-xs overflow-hidden border p-[1px] shadow-inner ${themeConfig.trackBorder}`}>
                <div
                  className={`h-full rounded-xs transition-all duration-300 ${
                    isGoalMet
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-300 shadow-[0_0_6px_rgba(16,185,129,0.5)]'
                      : themeConfig.barFill
                  }`}
                  style={{ width: `${clampedWidth}%` }}
                />
              </div>
              <span className="font-mono text-[9px] font-black text-slate-600 dark:text-slate-300 w-8 text-end shrink-0">
                {formatPercent(clampedWidth)}
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  };


  // WhatsApp Message Generator conforming exactly to the user's template
  // RULE: Any column/item whose Target == 0 is completely deleted from the WhatsApp message!
  // In retail stores:
  // - Line 1: Achieved Today / Daily Target (Ach: Today / Daily)
  // - Line 2: MTD Achieved / Monthly Target (Target: MTD / Monthly)
  // - Line 3: RE: % (Run-rate Realization % via user formula)
  const generateWhatsAppMessage = () => {
    const lines: string[] = [];
    lines.push('📊 Store Daily Performance');
    lines.push(`📅 Date: ${getTodayFormattedDate()}`);
    lines.push(`Store : ${storeName}`);
    lines.push('━━━━━━━━━━━━━━');

    // 1. Acquisition Box
    const low = computedItems.acq_low;
    const high = computedItems.acq_high;
    const cash = computedItems.vf_cash;

    const hasLow = low.parsedTarget > 0;
    const hasHigh = high.parsedTarget > 0;
    const hasCash = cash.parsedTarget > 0;

    if (hasLow || hasHigh || hasCash) {
      lines.push('📦 Acquisition Box');
      lines.push('━━━━━━━━━━━━━━');

      if (hasLow) {
        lines.push('🔹 Acq Low');
        lines.push(`Ach:  ${formatNumber(low.parsedToday)} / ${formatNumber(low.dailyTarget)}`);
        lines.push(`Target:  ${formatNumber(low.parsedMtd)} / ${formatNumber(low.parsedTarget)}`);
        lines.push('------------------------');
      }

      if (hasHigh) {
        lines.push('🔹 Acq High');
        lines.push(`Ach:  ${formatNumber(high.parsedToday)} / ${formatNumber(high.dailyTarget)}`);
        lines.push(`Target:  ${formatNumber(high.parsedMtd)} / ${formatNumber(high.parsedTarget)}`);
        lines.push('------------------------');
      }

      if (hasCash) {
        lines.push('🔹 Cash New');
        lines.push(`Ach:  ${formatNumber(cash.parsedToday)} / ${formatNumber(cash.dailyTarget)}`);
        lines.push(`Target:  ${formatNumber(cash.parsedMtd)} / ${formatNumber(cash.parsedTarget)}`);
        lines.push('------------------------');
      }

      // Today Acq Box Summary
      lines.push('------------------------');
      lines.push('🔹 Today Acq');
      lines.push(`Ach:  ${formatNumber(acqBox.todayAch)} / ${formatNumber(acqBox.dailyTarget)}`);
      lines.push(`Target:  ${formatNumber(acqBox.mtdAchievement)} / ${formatNumber(acqBox.monthlyTarget)}`);
      lines.push(`RE: ${formatPercent(calculateRE(acqBox.mtdAchievement, acqBox.monthlyTarget))}`);
      lines.push('━━━━━━━━━━━━━━');
    }

    // 2. Terminal
    const ter = computedItems.terminal;
    if (ter.parsedTarget > 0) {
      lines.push('💳 Terminal');
      lines.push('━━━━━━━━━━━━━━');
      lines.push(`Today Ach:  ${formatNumber(ter.parsedToday)} / ${formatNumber(ter.dailyTarget)}`);
      lines.push(`Target:  ${formatNumber(ter.parsedMtd)} / ${formatNumber(ter.parsedTarget)}`);
      lines.push(`RE: ${formatPercent(calculateRE(ter.parsedMtd, ter.parsedTarget))}`);
      lines.push('━━━━━━━━━━━━━━');
    }

    // 3. Enterprise
    const acc = computedItems.ent_acc;
    const gas = computedItems.ent_gas;
    const hasAcc = acc.parsedTarget > 0;
    const hasGas = gas.parsedTarget > 0;

    if (hasAcc || hasGas) {
      lines.push('💳 Enterprise');
      lines.push('━━━━━━━━━━━━━━');
      if (hasAcc) {
        lines.push(`Today Ach:  ${formatNumber(acc.parsedToday)} / ${formatNumber(acc.dailyTarget)}`);
        lines.push(`Acc:  ${formatNumber(acc.parsedMtd)} / ${formatNumber(acc.parsedTarget)}`);
        lines.push(`RE: ${formatPercent(calculateRE(acc.parsedMtd, acc.parsedTarget))}`);
      }
      if (hasAcc && hasGas) {
        lines.push('----------------');
      }
      if (hasGas) {
        lines.push(`Today Ach:  ${formatNumber(gas.parsedToday)} / ${formatNumber(gas.dailyTarget)}`);
        lines.push(`GAs:  ${formatNumber(gas.parsedMtd)} / ${formatNumber(gas.parsedTarget)}`);
        lines.push(`RE: ${formatPercent(calculateRE(gas.parsedMtd, gas.parsedTarget))}`);
      }
      lines.push('━━━━━━━━━━━━━━');
    }

    // 4. Fixed
    const adsl = computedItems.adsl;
    const home = computedItems.home;
    const hasAdsl = adsl.parsedTarget > 0;
    const hasHome = home.parsedTarget > 0;

    if (hasAdsl || hasHome) {
      lines.push('🌐 Fixed');
      lines.push('━━━━━━━━━━━━━');
      if (hasAdsl) {
        lines.push('🔹 ADSL');
        lines.push(`Today Ach:  ${formatNumber(adsl.parsedToday)} / ${formatNumber(adsl.dailyTarget)}`);
        lines.push(`Target:  ${formatNumber(adsl.parsedMtd)} / ${formatNumber(adsl.parsedTarget)}`);
        lines.push(`RE: ${formatPercent(calculateRE(adsl.parsedMtd, adsl.parsedTarget))}`);
      }
      if (hasAdsl && hasHome) {
        lines.push('---------------');
      }
      if (hasHome) {
        lines.push('🔹 @Home');
        lines.push(`Today Ach:  ${formatNumber(home.parsedToday)} / ${formatNumber(home.dailyTarget)}`);
        lines.push(`Target:  ${formatNumber(home.parsedMtd)} / ${formatNumber(home.parsedTarget)}`);
        lines.push(`RE: ${formatPercent(calculateRE(home.parsedMtd, home.parsedTarget))}`);
      }
      lines.push('━━━━━━━━━━━━━━');
    }

    // 5. Red Sales
    const redTarget = parseFloat(redSalesTarget) || 0;
    const redToday = parseFloat(redSalesToday) || 0;
    if (redTarget > 0) {
      lines.push(`Red Sales:  ${formatNumber(redToday)} / ${formatNumber(redTarget)}`);
      lines.push('━━━━━━━━━━━━━━');
    }

    // 6. Overall & TNPS (Overall represents Overall Projection %)
    lines.push(`Overall: ${formatPercent(overallProjectionPercent)}`);
    const tnpsVal = computedTnpsRows[0]?.tnpsPercent;
    lines.push(`TNPS: ${typeof tnpsVal === 'number' ? formatPercent(tnpsVal) : '0%'}`);
    lines.push('Thanks 🙏');

    return lines.join('\n');
  };

  // State update handlers
  const handleItemFieldChange = (itemKey: string, field: 'monthlyTarget' | 'mtdAchievement' | 'todayAch', value: string) => {
    setItems((prev) => ({
      ...prev,
      [itemKey]: {
        ...prev[itemKey],
        [field]: value,
      },
    }));
  };

  const handleBoxWeightChange = (boxKey: keyof BoxWeights, rawValue: string) => {
    const normalized = rawValue
      .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 1632))
      .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 1776))
      .replace(/[^0-9.]/g, '');
    setBoxWeights((prev) => ({
      ...prev,
      [boxKey]: normalized,
    }));
  };

  const handleTnpsChange = (index: number, field: keyof TnpsRowData, val: string) => {
    const updated = [...tnpsRows];
    updated[index] = { ...updated[index], [field]: val };
    setTnpsRows(updated);
  };

  // Daily Workflow: Add Today's Achievement to MTD & preserve daily for WhatsApp
  const handleAddTodayToMtd = () => {
    const todayAcq = acqBox.todayAch;
    const todayTer = terminalBox.todayAch;
    const todayEnt = enterpriseBox.todayAch;
    const todayFix = fixedBox.todayAch;
    const todayTotal = todayAcq + todayTer + todayEnt + todayFix;

    const nextLastSaved: Record<string, number> = { ...lastSavedToday };
    const updated: Record<string, ItemData> = {};
    let hasNetChange = false;

    Object.keys(items).forEach((k) => {
      const cur = items[k];
      const curMtd = parseFloat(cur.mtdAchievement) || 0;
      const curToday = parseFloat(cur.todayAch) || 0;
      const previouslySaved = lastSavedToday[k] || 0;
      const delta = curToday - previouslySaved;

      if (delta !== 0) {
        hasNetChange = true;
      }

      updated[k] = {
        ...cur,
        mtdAchievement: String(Math.max(0, Math.round(curMtd + delta))),
        todayAch: cur.todayAch, // PRESERVE: Never wipe todayAch! Keeps it for screen display & WhatsApp
      };
      nextLastSaved[k] = curToday;
    });

    setItems(updated);
    setLastSavedToday(nextLastSaved);

    // Only decrement remaining shifts on the first save of the day
    if (!isTodaySaved && parsedRemainingShifts > 1) {
      setRemainingShifts(String(parsedRemainingShifts - 1));
    }
    setIsTodaySaved(true);

    // Save today's achievement into 7-day history
    setDailyHistory((prev) => {
      const now = new Date();
      const todayStr = `${now.getDate()}/${now.getMonth() + 1}`;
      const dayNames = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
      const todayName = dayNames[now.getDay()];
      const next = [...prev];
      if (next.length > 0) {
        next[next.length - 1] = {
          ...next[next.length - 1],
          date: todayStr,
          dayLabel: `اليوم (${todayName})`,
          acq: todayAcq,
          terminal: todayTer,
          enterprise: todayEnt,
          fixed: todayFix,
          total: todayTotal,
        };
      }
      return next;
    });

    if (hasNetChange || !isTodaySaved) {
      setSaveToast('تم حفظ التحقيق اليومي إلي MTD بنجاح وانتقلت الأرقام إلى رسالة الواتس اب! 💾📱');
    } else {
      setSaveToast('التحقيق اليومي محفوظ مسبقاً ومضاف لـ MTD ورسالة الواتس جاهزة بالمحقق اليومي! 📱');
    }
    setTimeout(() => setSaveToast(null), 3500);

    // Open WhatsApp modal automatically with the preserved daily achievement!
    setShowWhatsAppModal(true);
  };

  // Start New Shift / Day: Only clear today's achievements without touching targets or MTD
  const handleResetTodayOnly = () => {
    const updated: Record<string, ItemData> = {};
    Object.keys(items).forEach((k) => {
      updated[k] = {
        ...items[k],
        todayAch: '0',
      };
    });
    setItems(updated);
    setRedSalesToday('0');
    setLastSavedToday({});
    setIsTodaySaved(false);
    setShowResetModal(false);
    setSaveToast('تم تصفير المحقق اليومي فقط بنجاح لبدء شفت جديد! 🌅');
    setTimeout(() => setSaveToast(null), 3000);
  };

  // Presets
  const handleLoadTestPreset = () => {
    setItems(SAMPLE_TEST_ITEMS);
    setBoxWeights(DEFAULT_BOX_WEIGHTS);
    setTnpsRows(SAMPLE_TNPS_ROWS);
    setTotalShifts('25');
    setRemainingShifts('10');
    setRedSalesToday('2');
    setRedSalesTarget('15');
    setLastSavedToday({});
    setIsTodaySaved(false);
    setShowResetModal(false);
    setSaveToast('تم تحميل نموذج المتجر النموذجي بنجاح!');
    setTimeout(() => setSaveToast(null), 3000);
  };

  const handleLoadStandardDemo = () => {
    setItems(DEFAULT_ITEMS);
    setBoxWeights(DEFAULT_BOX_WEIGHTS);
    setTnpsRows(DEFAULT_TNPS_ROWS);
    setTotalShifts('25');
    setRemainingShifts('10');
    setRedSalesToday('0');
    setRedSalesTarget('0');
    setLastSavedToday({});
    setIsTodaySaved(false);
    setShowResetModal(false);
    setSaveToast('تم تصفير التارجت مع الحفاظ على أوزان البوكسات القياسية.');
    setTimeout(() => setSaveToast(null), 3000);
  };

  const handleClearAll = () => {
    const cleared: Record<string, ItemData> = {};
    Object.keys(DEFAULT_ITEMS).forEach((k) => {
      cleared[k] = { ...DEFAULT_ITEMS[k], monthlyTarget: '0', mtdAchievement: '0', todayAch: '0' };
    });
    setItems(cleared);
    setTnpsRows(DEFAULT_TNPS_ROWS);
    setRedSalesToday('0');
    setRedSalesTarget('0');
    setLastSavedToday({});
    setIsTodaySaved(false);
    setShowResetModal(false);
    setSaveToast('تم تصفير جميع القيم.');
    setTimeout(() => setSaveToast(null), 3000);
  };

  const handleCopyWhatsApp = () => {
    const msg = generateWhatsAppMessage();
    navigator.clipboard.writeText(msg);
    setCopiedWhatsApp(true);
    setTimeout(() => setCopiedWhatsApp(false), 2000);
  };

  const copyShareUrl = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const whatsappShareUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(generateWhatsAppMessage())}`;

  return (
    <div className={`min-h-screen w-full flex flex-col justify-between p-1.5 sm:p-2.5 transition-colors duration-150 select-text ${
      darkMode ? 'bg-[#070D1E] text-slate-100' : 'bg-slate-50 text-slate-900'
    }`}>
      {/* Toast Notification */}
      {saveToast && (
        <div className="fixed top-2 left-1/2 -translate-x-1/2 z-50 px-3 py-1.5 rounded-full text-[11px] font-semibold bg-emerald-600 text-white shadow-xl flex items-center gap-1.5 animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>{saveToast}</span>
        </div>
      )}

      {/* Main Container */}
      <div className="w-full max-w-4xl mx-auto flex flex-col gap-1.5">
        
        {/* Top Instructions Marquee Bar (Thin, Elegant, Ultra-Slow for Easy Reading) */}
        <div className={`w-full overflow-hidden rounded-md border py-0.5 px-2 text-[9px] sm:text-[10px] font-normal select-none flex items-center shadow-2xs ${
          darkMode ? 'bg-[#0B132B] border-teal-900/60 text-teal-300' : 'bg-teal-50/90 border-teal-200 text-teal-950'
        }`} dir="rtl">
          <div className="flex items-center gap-1 shrink-0 ps-1 font-bold text-teal-600 dark:text-teal-400">
            <Sparkles className="w-3 h-3 shrink-0 animate-pulse" />
            <span className="text-[8px] sm:text-[9px] uppercase tracking-wider bg-teal-600/15 dark:bg-teal-400/15 px-1 py-0.2 rounded border border-teal-500/30">
              توجيه:
            </span>
          </div>
          <div className="flex-1 overflow-hidden relative ms-1.5">
            <div className="animate-slow-marquee inline-block whitespace-nowrap">
              <span>قم بكتابة التارجت وعدد الشفتات مره واحده وعند الضغط على زر حفظ يقوم بالحفظ تلقائيا والإضافة إلى اليوم السابق، فقط قم بكتابة المحقق اليومي بعد ذلك وسيتم الحساب تلقائيا</span>
              <span className="mx-8 opacity-60 text-teal-500">✦</span>
              <span>قم بكتابة التارجت وعدد الشفتات مره واحده وعند الضغط على زر حفظ يقوم بالحفظ تلقائيا والإضافة إلى اليوم السابق، فقط قم بكتابة المحقق اليومي بعد ذلك وسيتم الحساب تلقائيا</span>
            </div>
          </div>
        </div>

        {/* Header Section */}
        <header className="flex flex-col gap-1 shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <div className="p-1 rounded bg-teal-600 text-white shadow-2xs">
                <Store className="w-4 h-4" />
              </div>
              <div className="leading-tight">
                <h1 className="text-xs sm:text-sm font-bold tracking-tight">
                  Target Calculator
                </h1>
                <input
                  type="text"
                  value={storeName}
                  onChange={(e) => setStoreName(e.target.value)}
                  placeholder="Store Name"
                  className={`text-[9px] sm:text-[10px] font-semibold outline-none bg-transparent hover:underline cursor-text ${
                    darkMode ? 'text-teal-400 placeholder:text-slate-600' : 'text-teal-700 placeholder:text-slate-400'
                  }`}
                  title="Click to edit Store Name (saved automatically)"
                />
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex items-center gap-1">
              {/* WhatsApp Quick Button */}
              <button
                onClick={() => setShowWhatsAppModal(true)}
                className="inline-flex items-center gap-1 px-2.5 py-1 text-[10px] font-bold rounded bg-emerald-600 hover:bg-emerald-500 text-white shadow-2xs cursor-pointer transition-all active:scale-95"
                title="Send / Preview Daily Report on WhatsApp"
              >
                <MessageSquare className="w-3 h-3 fill-current" />
                <span>Sent WhatsApp</span>
              </button>

              {/* View Toggle */}
              <button
                onClick={() => setViewMode(viewMode === 'cards' ? 'table' : 'cards')}
                className={`inline-flex items-center gap-0.5 px-1.5 py-1 text-[9px] border rounded transition-colors cursor-pointer ${
                  darkMode ? 'bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700' : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'
                }`}
                title="Toggle between Easy Mobile Cards and Table"
              >
                {viewMode === 'cards' ? <TableIcon className="w-3 h-3" /> : <LayoutGrid className="w-3 h-3" />}
                <span>{viewMode === 'cards' ? 'Table' : 'Cards'}</span>
              </button>

              {/* Dark Mode */}
              <button
                onClick={toggleDarkMode}
                className={`inline-flex items-center gap-0.5 px-1.5 py-1 text-[9px] border rounded transition-colors cursor-pointer ${
                  darkMode ? 'bg-slate-800 text-amber-300 border-slate-600 hover:bg-slate-700' : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'
                }`}
                title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
              >
                {darkMode ? <Sun className="w-3 h-3" /> : <Moon className="w-3 h-3" />}
                <span>{darkMode ? 'Light' : 'Dark'}</span>
              </button>

              {/* Reset */}
              <button
                onClick={() => setShowResetModal(true)}
                className={`inline-flex items-center gap-0.5 px-1.5 py-1 text-[9px] border rounded transition-colors cursor-pointer ${
                  darkMode ? 'bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700' : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'
                }`}
                title="Reset or switch presets"
              >
                <RotateCcw className="w-3 h-3 text-slate-400" />
                <span>Reset</span>
              </button>

              {/* Share */}
              <button
                onClick={() => setShowShareModal(true)}
                className={`inline-flex items-center gap-0.5 px-1.5 py-1 text-[9px] border rounded transition-colors cursor-pointer ${
                  darkMode ? 'bg-teal-950 text-teal-300 border-teal-800 hover:bg-teal-900' : 'bg-teal-50 text-teal-700 border-teal-200 hover:bg-teal-100'
                }`}
                title="Public share link"
              >
                <Share2 className="w-3 h-3" />
                <span>Share</span>
              </button>
            </div>
          </div>

          {/* Shifts & Daily Add to MTD Action Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-1.5 text-[10px]">
            {/* Box 1: Total Shifts */}
            <div className={`flex items-center justify-between border rounded py-1 px-2.5 transition-colors ${
              darkMode ? 'bg-[#0E172E] border-slate-700' : 'bg-white border-slate-300'
            }`}>
              <span className={`text-[9px] uppercase tracking-wider font-semibold ${
                darkMode ? 'text-slate-400' : 'text-slate-600'
              }`}>
                Total Shifts
              </span>
              <input
                type="number"
                inputMode="numeric"
                min="1"
                step="1"
                value={totalShifts}
                onFocus={(e) => e.target.select()}
                onChange={(e) => setTotalShifts(e.target.value)}
                className={`w-14 text-center font-mono text-xs font-bold outline-none bg-transparent ${
                  darkMode ? 'text-white' : 'text-slate-900'
                }`}
              />
            </div>

            {/* Box 2: Remaining Shifts */}
            <div className={`flex items-center justify-between border rounded py-1 px-2.5 transition-colors ${
              darkMode ? 'bg-[#0E172E] border-slate-700' : 'bg-white border-slate-300'
            }`}>
              <span className={`text-[9px] uppercase tracking-wider font-semibold ${
                darkMode ? 'text-teal-400' : 'text-teal-700'
              }`}>
                Remaining Shifts
              </span>
              <input
                type="number"
                inputMode="numeric"
                min="0"
                step="1"
                value={remainingShifts}
                onFocus={(e) => e.target.select()}
                onChange={(e) => setRemainingShifts(e.target.value)}
                className={`w-14 text-center font-mono text-xs font-bold outline-none bg-transparent ${
                  darkMode ? 'text-teal-300' : 'text-teal-700'
                }`}
              />
            </div>

            {/* Box 3: Daily Action Button - Ultra Eye-Catching & Prominent */}
            <div className="flex items-center gap-1">
              <button
                onClick={handleAddTodayToMtd}
                className="relative group overflow-hidden flex-1 flex items-center justify-center gap-1.5 rounded-lg py-1 px-2 text-center font-black text-[10px] sm:text-[11px] text-white bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 hover:from-emerald-500 hover:to-teal-500 shadow-md shadow-emerald-950/40 border-2 border-emerald-300 dark:border-emerald-400 ring-2 ring-emerald-400/40 hover:ring-emerald-300 transition-all duration-150 cursor-pointer active:scale-95"
                title="اضغط هنا لحفظ التحقيق اليومي إلي MTD"
              >
                <span className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-200" />
                <div className="p-0.5 rounded-full bg-white/20 group-hover:rotate-90 transition-transform duration-200">
                  <Plus className="w-3.5 h-3.5 stroke-[3]" />
                </div>
                <span className="relative z-10 tracking-tight drop-shadow-sm font-black truncate">
                  اضغط هنا لحفظ التحقيق اليومي إلي MTD 💾
                </span>
              </button>

              {isTodaySaved && (
                <button
                  onClick={handleResetTodayOnly}
                  className="px-2 py-1 rounded-lg text-[9px] font-bold border border-amber-500/60 bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/60 dark:hover:bg-amber-900/60 text-amber-800 dark:text-amber-200 flex items-center justify-center gap-1 shrink-0 cursor-pointer transition-all active:scale-95 shadow-2xs"
                  title="تصفير المحقق اليومي فقط لبدء شفت جديد"
                >
                  <RotateCcw className="w-3 h-3 text-amber-500" />
                  <span className="hidden sm:inline">شفت جديد</span>
                </button>
              )}
            </div>
          </div>

          {/* BOX WEIGHTS AT THE TOP (Ultra-Compact Single Row) */}
          <div className={`border-2 rounded-lg py-1 px-1.5 transition-colors shadow-2xs flex flex-wrap sm:flex-nowrap items-center justify-between gap-1.5 text-[9px] sm:text-[10px] font-bold ${
            darkMode ? 'bg-[#0E172E] border-slate-700' : 'bg-white border-slate-300'
          }`}>
            <div className="flex items-center gap-1 shrink-0 ps-0.5">
              <Layers className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
              <span className="font-black text-slate-800 dark:text-slate-100">الأوزان:</span>
              <span className={`text-[8px] sm:text-[9px] font-mono font-bold px-1.5 py-0.2 rounded-full ${
                isWeightValid 
                  ? 'bg-emerald-600 text-white shadow-2xs' 
                  : 'bg-amber-600 text-white font-bold animate-pulse'
              }`}>
                {Math.round(totalBoxWeight)}% {isWeightValid ? '✓' : '⚠️'}
              </span>
            </div>

            <div className="grid grid-cols-5 gap-1 flex-1 text-center min-w-[260px]">
              {/* Box 1: Acquisition (60%) */}
              <div className={`flex items-center justify-center gap-0.5 py-0.5 px-1 rounded-md border ${
                darkMode ? 'bg-teal-950/80 border-teal-500 text-teal-100' : 'bg-teal-50 border-teal-500 text-teal-950'
              }`}>
                <span className="truncate text-[9px] font-black">Acq:</span>
                <input
                  type="text"
                  inputMode="decimal"
                  value={boxWeights.acq}
                  onFocus={(e) => e.target.select()}
                  onChange={(e) => handleBoxWeightChange('acq', e.target.value)}
                  className="w-8 sm:w-9 text-center font-mono font-black text-[10px] sm:text-xs bg-transparent outline-none focus:bg-white/20 dark:focus:bg-black/20 rounded"
                  placeholder="0"
                />
                <span className="text-[8px] font-bold">%</span>
              </div>

              {/* Box 2: Terminal (10%) */}
              <div className={`flex items-center justify-center gap-0.5 py-0.5 px-1 rounded-md border ${
                darkMode ? 'bg-sky-950/80 border-sky-500 text-sky-100' : 'bg-sky-50 border-sky-500 text-sky-950'
              }`}>
                <span className="truncate text-[9px] font-black">Ter:</span>
                <input
                  type="text"
                  inputMode="decimal"
                  value={boxWeights.terminal}
                  onFocus={(e) => e.target.select()}
                  onChange={(e) => handleBoxWeightChange('terminal', e.target.value)}
                  className="w-8 sm:w-9 text-center font-mono font-black text-[10px] sm:text-xs bg-transparent outline-none focus:bg-white/20 dark:focus:bg-black/20 rounded"
                  placeholder="0"
                />
                <span className="text-[8px] font-bold">%</span>
              </div>

              {/* Box 3: Enterprise (10%) */}
              <div className={`flex items-center justify-center gap-0.5 py-0.5 px-1 rounded-md border ${
                darkMode ? 'bg-blue-950/80 border-blue-500 text-blue-100' : 'bg-blue-50 border-blue-500 text-blue-950'
              }`}>
                <span className="truncate text-[9px] font-black">Ent:</span>
                <input
                  type="text"
                  inputMode="decimal"
                  value={boxWeights.enterprise}
                  onFocus={(e) => e.target.select()}
                  onChange={(e) => handleBoxWeightChange('enterprise', e.target.value)}
                  className="w-8 sm:w-9 text-center font-mono font-black text-[10px] sm:text-xs bg-transparent outline-none focus:bg-white/20 dark:focus:bg-black/20 rounded"
                  placeholder="0"
                />
                <span className="text-[8px] font-bold">%</span>
              </div>

              {/* Box 4: ADSL (16%) */}
              <div className={`flex items-center justify-center gap-0.5 py-0.5 px-1 rounded-md border ${
                darkMode ? 'bg-indigo-950/80 border-indigo-500 text-indigo-100' : 'bg-indigo-50 border-indigo-500 text-indigo-950'
              }`}>
                <span className="truncate text-[9px] font-black">ADSL:</span>
                <input
                  type="text"
                  inputMode="decimal"
                  value={boxWeights.adsl}
                  onFocus={(e) => e.target.select()}
                  onChange={(e) => handleBoxWeightChange('adsl', e.target.value)}
                  className="w-8 sm:w-9 text-center font-mono font-black text-[10px] sm:text-xs bg-transparent outline-none focus:bg-white/20 dark:focus:bg-black/20 rounded"
                  placeholder="0"
                />
                <span className="text-[8px] font-bold">%</span>
              </div>

              {/* Box 5: @Home (4%) */}
              <div className={`flex items-center justify-center gap-0.5 py-0.5 px-1 rounded-md border ${
                darkMode ? 'bg-purple-950/80 border-purple-500 text-purple-100' : 'bg-purple-50 border-purple-500 text-purple-950'
              }`}>
                <span className="truncate text-[9px] font-black">Home:</span>
                <input
                  type="text"
                  inputMode="decimal"
                  value={boxWeights.home}
                  onFocus={(e) => e.target.select()}
                  onChange={(e) => handleBoxWeightChange('home', e.target.value)}
                  className="w-8 sm:w-9 text-center font-mono font-black text-[10px] sm:text-xs bg-transparent outline-none focus:bg-white/20 dark:focus:bg-black/20 rounded"
                  placeholder="0"
                />
                <span className="text-[8px] font-bold">%</span>
              </div>
            </div>
          </div>

          {/* OVERALL SUMMARY BANNER (Vibrant High-Contrast, Height-Optimized) */}
          <div className="grid grid-cols-2 gap-1.5 text-center">
            {/* OVERALL MTD % */}
            <div className="p-1.5 sm:p-2 rounded-lg border-2 border-teal-400 bg-gradient-to-br from-teal-800 to-teal-950 text-white shadow-md flex flex-col items-center justify-center">
              <span className="text-[9px] sm:text-[10px] font-extrabold uppercase tracking-wider text-teal-200">
                OVERALL MTD %
              </span>
              <span className="text-xl sm:text-2xl font-mono font-black tracking-tight text-white my-0.5 drop-shadow-sm">
                {formatPercent(overallMtdPercent)}
              </span>
              <span className="text-[8px] font-bold text-teal-200/90">
                المحقق الفعلي الموزون
              </span>
            </div>

            {/* OVERALL PROJECTION % */}
            <div className="p-1.5 sm:p-2 rounded-lg border-2 border-emerald-400 bg-gradient-to-br from-slate-900 to-black text-white shadow-md flex flex-col items-center justify-center">
              <span className="text-[9px] sm:text-[10px] font-extrabold uppercase tracking-wider text-emerald-400">
                OVERALL PROJ %
              </span>
              <span className="text-xl sm:text-2xl font-mono font-black text-emerald-400 tracking-tight my-0.5 drop-shadow-sm">
                {formatPercent(overallProjectionPercent)}
              </span>
              <span className="text-[8px] font-bold text-slate-300">
                المتوقع لنهاية الشهر
              </span>
            </div>
          </div>
        </header>

        {/* INPUTS CONTAINER - ULTRA-COMPACT SLEEK CARDS (High-Contrast, Crisp Rounded Borders) */}
        {viewMode === 'cards' ? (
          <div className="flex flex-col gap-1.5">
            
            {/* BOX 1: 📦 Acquisition Box (60% كاملاً) */}
            <div className={`rounded-xl border-2 overflow-hidden shadow-xs transition-colors ${
              darkMode ? 'bg-[#0E172E] border-teal-600' : 'bg-white border-teal-500'
            }`}>
              {/* Box Header Banner */}
              <div className="flex items-center justify-between px-2.5 py-1.5 bg-teal-700 text-white text-xs sm:text-sm font-black shadow-xs">
                <div className="flex items-center gap-1.5">
                  <span>📦 Acquisition Box (وزن {boxWeights.acq}%)</span>
                </div>
                <div className="flex items-center gap-1.5 sm:gap-2 font-mono text-[10px] sm:text-xs">
                  <span>Target: {formatNumber(acqBox.monthlyTarget)}</span>
                  <span>MTD: {formatNumber(acqBox.mtdAchievement)}</span>
                  <span className="px-1.5 py-0.5 rounded bg-black/40 font-bold text-teal-200" title="MTD %">
                    MTD: {formatPercent(acqBox.mtdPercent)}
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-emerald-950/80 border border-emerald-400/50 font-black text-emerald-300" title="RE %">
                    RE: {formatPercent(calculateRE(acqBox.mtdAchievement, acqBox.monthlyTarget))}
                  </span>
                </div>
              </div>

              {/* Daily Achievement Goal Visualizer */}
              <BoxDailyGoalVisualizer
                boxLabel="Acquisition"
                todayAch={acqBox.todayAch}
                dailyTarget={acqBox.dailyTarget}
                colorTheme="teal"
                subChips={[
                  { label: 'Low', today: computedItems.acq_low.todayAch, target: computedItems.acq_low.dailyTarget },
                  { label: 'High', today: computedItems.acq_high.todayAch, target: computedItems.acq_high.dailyTarget },
                  { label: 'Cash', today: computedItems.vf_cash.todayAch, target: computedItems.vf_cash.dailyTarget },
                ]}
              />

              {/* Box Column Headers */}
              <div className="grid grid-cols-12 gap-1 px-2 py-0.5 bg-slate-100 dark:bg-slate-900/90 text-[9px] font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 text-center items-center">
                <div className="col-span-3 text-start ps-1">الصنف / Category</div>
                <div className="col-span-2">Target</div>
                <div className="col-span-2">MTD</div>
                <div className="col-span-2">المتبقي</div>
                <div className="col-span-1">اليومي</div>
                <div className="col-span-2">اليوم ✍️</div>
              </div>

              {/* Sub-items: Acq Low, Acq High, Cash New */}
              <div className="divide-y divide-slate-100 dark:divide-slate-800/80">
                {[
                  { key: 'acq_low', title: '🔹 Acq Low', label: 'Low Acq' },
                  { key: 'acq_high', title: '🔹 Acq High', label: 'High Acq' },
                  { key: 'vf_cash', title: '🔹 Cash New', label: 'Cash New' },
                ].map(({ key, title }) => {
                  const itm = computedItems[key];
                  return (
                    <div key={key} className="grid grid-cols-12 gap-1 items-center px-2 py-1 text-center hover:bg-slate-500/5 transition-colors">
                      {/* Name + MTD % Badge */}
                      <div className="col-span-3 flex items-center justify-between gap-1 text-start ps-1 overflow-hidden">
                        <span className="font-extrabold text-[11px] truncate text-slate-800 dark:text-slate-100">{title}</span>
                        <span className={`px-1 py-0.2 rounded font-mono font-black text-[9px] shrink-0 ${getPercentBadge(itm.mtdPercent)}`}>
                          {formatPercent(itm.mtdPercent)}
                        </span>
                      </div>

                      {/* Target الشهري */}
                      <div className="col-span-2">
                        <input
                          type="number"
                          min="0"
                          step="1"
                          value={itm.monthlyTarget}
                          onFocus={(e) => e.target.select()}
                          onChange={(e) => handleItemFieldChange(key, 'monthlyTarget', e.target.value)}
                          className={`w-full text-center font-mono font-bold text-xs py-0.5 rounded border ${
                            darkMode ? 'bg-slate-900 border-slate-700 text-white' : 'bg-white border-slate-300 text-slate-900'
                          } focus:border-teal-500 outline-none`}
                          placeholder="0"
                        />
                      </div>

                      {/* MTD المحقق */}
                      <div className="col-span-2">
                        <input
                          type="number"
                          min="0"
                          step="1"
                          value={itm.mtdAchievement}
                          onFocus={(e) => e.target.select()}
                          onChange={(e) => handleItemFieldChange(key, 'mtdAchievement', e.target.value)}
                          className={`w-full text-center font-mono font-black text-xs py-0.5 rounded border ${
                            darkMode ? 'bg-teal-950/60 border-teal-500 text-teal-200' : 'bg-teal-50 border-teal-400 text-teal-950'
                          } focus:border-teal-500 outline-none`}
                          placeholder="0"
                        />
                      </div>

                      {/* المتبقي Remaining */}
                      <div className="col-span-2">
                        <div className={`w-full font-mono font-black text-xs py-0.5 rounded border ${
                          darkMode ? 'bg-amber-950/40 border-amber-600/70 text-amber-200' : 'bg-amber-50 border-amber-300 text-amber-950'
                        }`}>
                          {formatNumber(itm.remainingTarget)}
                        </div>
                      </div>

                      {/* اليومي Daily Target */}
                      <div className="col-span-1">
                        <div className={`w-full font-mono font-black text-xs py-0.5 rounded border ${
                          darkMode ? 'bg-emerald-950/40 border-emerald-600/70 text-emerald-200' : 'bg-emerald-50 border-emerald-300 text-emerald-950'
                        }`}>
                          {formatNumber(itm.dailyTarget)}
                        </div>
                      </div>

                      {/* محقق اليوم Today Ach */}
                      <div className="col-span-2">
                        <input
                          type="number"
                          min="0"
                          step="1"
                          value={itm.todayAch}
                          onFocus={(e) => e.target.select()}
                          onChange={(e) => handleItemFieldChange(key, 'todayAch', e.target.value)}
                          className={`w-full text-center font-mono font-black text-xs py-0.5 rounded border-2 ${
                            darkMode ? 'bg-blue-950/70 border-blue-400 text-blue-100' : 'bg-blue-50 border-blue-500 text-blue-950'
                          } focus:ring-1 focus:ring-blue-400 outline-none`}
                          placeholder="0"
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Box Summary Row */}
              <div className="grid grid-cols-12 gap-1 items-center px-2 py-0.5 bg-teal-500/10 text-center font-black text-[10px] border-t border-teal-500/30">
                <div className="col-span-3 text-start ps-1 text-teal-900 dark:text-teal-200 font-extrabold truncate">
                  إجمالي بوكس Acq
                </div>
                <div className="col-span-2 font-mono font-black">{formatNumber(acqBox.monthlyTarget)}</div>
                <div className="col-span-2 font-mono font-black text-teal-700 dark:text-teal-300">{formatNumber(acqBox.mtdAchievement)}</div>
                <div className="col-span-2 font-mono font-black text-amber-800 dark:text-amber-300">{formatNumber(acqBox.remainingTarget)}</div>
                <div className="col-span-1 font-mono font-black text-emerald-800 dark:text-emerald-300">{formatNumber(acqBox.dailyTarget)}</div>
                <div className="col-span-2 font-mono font-black text-blue-800 dark:text-blue-300">{formatNumber(acqBox.todayAch)}</div>
              </div>
            </div>

            {/* BOX 2: 💳 Terminal Box (10%) */}
            <div className={`rounded-xl border-2 overflow-hidden shadow-xs transition-colors ${
              darkMode ? 'bg-[#0E172E] border-sky-600' : 'bg-white border-sky-500'
            }`}>
              <div className="flex items-center justify-between px-2.5 py-1.5 bg-sky-700 text-white text-xs sm:text-sm font-black shadow-xs">
                <span>💳 Terminal Box (وزن {boxWeights.terminal}%)</span>
                <div className="flex items-center gap-1.5 font-mono text-[10px] sm:text-xs">
                  <span className="px-1.5 py-0.5 rounded bg-black/40 text-sky-200 font-bold" title="MTD %">
                    MTD: {formatPercent(terminalBox.mtdPercent)}
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-emerald-950/80 border border-emerald-400/50 text-emerald-300 font-black" title="RE %">
                    RE: {formatPercent(calculateRE(terminalBox.mtdAchievement, terminalBox.monthlyTarget))}
                  </span>
                </div>
              </div>

              {/* Daily Achievement Goal Visualizer */}
              <BoxDailyGoalVisualizer
                boxLabel="Terminal"
                todayAch={terminalBox.todayAch}
                dailyTarget={terminalBox.dailyTarget}
                colorTheme="sky"
              />

              {/* Column Headers */}
              <div className="grid grid-cols-12 gap-1 px-2 py-0.5 bg-slate-100 dark:bg-slate-900/90 text-[9px] font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 text-center items-center">
                <div className="col-span-3 text-start ps-1">الصنف / Category</div>
                <div className="col-span-2">Target</div>
                <div className="col-span-2">MTD</div>
                <div className="col-span-2">المتبقي</div>
                <div className="col-span-1">اليومي</div>
                <div className="col-span-2">اليوم ✍️</div>
              </div>

              <div className="grid grid-cols-12 gap-1 items-center px-2 py-1 text-center hover:bg-slate-500/5 transition-colors">
                <div className="col-span-3 flex items-center justify-between gap-1 text-start ps-1 overflow-hidden">
                  <span className="font-extrabold text-[11px] truncate text-slate-800 dark:text-slate-100">💳 Terminal</span>
                  <span className={`px-1 py-0.2 rounded font-mono font-black text-[9px] shrink-0 ${getPercentBadge(terminalBox.mtdPercent)}`}>
                    {formatPercent(terminalBox.mtdPercent)}
                  </span>
                </div>
                <div className="col-span-2">
                  <input
                    type="number"
                    min="0"
                    step="1"
                    value={items.terminal.monthlyTarget}
                    onFocus={(e) => e.target.select()}
                    onChange={(e) => handleItemFieldChange('terminal', 'monthlyTarget', e.target.value)}
                    className={`w-full text-center font-mono font-bold text-xs py-0.5 rounded border ${
                      darkMode ? 'bg-slate-900 border-slate-700 text-white' : 'bg-white border-slate-300 text-slate-900'
                    } focus:border-sky-500 outline-none`}
                    placeholder="0"
                  />
                </div>
                <div className="col-span-2">
                  <input
                    type="number"
                    min="0"
                    step="1"
                    value={items.terminal.mtdAchievement}
                    onFocus={(e) => e.target.select()}
                    onChange={(e) => handleItemFieldChange('terminal', 'mtdAchievement', e.target.value)}
                    className={`w-full text-center font-mono font-black text-xs py-0.5 rounded border ${
                      darkMode ? 'bg-sky-950/60 border-sky-500 text-sky-200' : 'bg-sky-50 border-sky-400 text-sky-950'
                    } focus:border-sky-500 outline-none`}
                    placeholder="0"
                  />
                </div>
                <div className="col-span-2">
                  <div className={`w-full font-mono font-black text-xs py-0.5 rounded border ${
                    darkMode ? 'bg-amber-950/40 border-amber-600/70 text-amber-200' : 'bg-amber-50 border-amber-300 text-amber-950'
                  }`}>
                    {formatNumber(terminalBox.remainingTarget)}
                  </div>
                </div>
                <div className="col-span-1">
                  <div className={`w-full font-mono font-black text-xs py-0.5 rounded border ${
                    darkMode ? 'bg-emerald-950/40 border-emerald-600/70 text-emerald-200' : 'bg-emerald-50 border-emerald-300 text-emerald-950'
                  }`}>
                    {formatNumber(terminalBox.dailyTarget)}
                  </div>
                </div>
                <div className="col-span-2">
                  <input
                    type="number"
                    min="0"
                    step="1"
                    value={items.terminal.todayAch}
                    onFocus={(e) => e.target.select()}
                    onChange={(e) => handleItemFieldChange('terminal', 'todayAch', e.target.value)}
                    className={`w-full text-center font-mono font-black text-xs py-0.5 rounded border-2 ${
                      darkMode ? 'bg-blue-950/70 border-blue-400 text-blue-100' : 'bg-blue-50 border-blue-500 text-blue-950'
                    } focus:ring-1 focus:ring-blue-400 outline-none`}
                    placeholder="0"
                  />
                </div>
              </div>
            </div>

            {/* BOX 3: 💳 Enterprise Box (10% كاملاً: Acc + GAs) */}
            <div className={`rounded-xl border-2 overflow-hidden shadow-xs transition-colors ${
              darkMode ? 'bg-[#0E172E] border-blue-600' : 'bg-white border-blue-500'
            }`}>
              <div className="flex items-center justify-between px-2.5 py-1.5 bg-blue-700 text-white text-xs sm:text-sm font-black shadow-xs">
                <span>💳 Enterprise Box (وزن {boxWeights.enterprise}%)</span>
                <div className="flex items-center gap-1.5 sm:gap-2 font-mono text-[10px] sm:text-xs">
                  <span>Target: {formatNumber(enterpriseBox.monthlyTarget)}</span>
                  <span>MTD: {formatNumber(enterpriseBox.mtdAchievement)}</span>
                  <span className="px-1.5 py-0.5 rounded bg-black/40 text-blue-200 font-bold" title="MTD %">
                    MTD: {formatPercent(enterpriseBox.mtdPercent)}
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-emerald-950/80 border border-emerald-400/50 text-emerald-300 font-black" title="RE %">
                    RE: {formatPercent(calculateRE(enterpriseBox.mtdAchievement, enterpriseBox.monthlyTarget))}
                  </span>
                </div>
              </div>

              {/* Daily Achievement Goal Visualizer */}
              <BoxDailyGoalVisualizer
                boxLabel="Enterprise"
                todayAch={enterpriseBox.todayAch}
                dailyTarget={enterpriseBox.dailyTarget}
                colorTheme="blue"
                subChips={[
                  { label: 'Acc', today: computedItems.ent_acc.todayAch, target: computedItems.ent_acc.dailyTarget },
                  { label: 'GAs', today: computedItems.ent_gas.todayAch, target: computedItems.ent_gas.dailyTarget },
                ]}
              />

              {/* Column Headers */}
              <div className="grid grid-cols-12 gap-1 px-2 py-0.5 bg-slate-100 dark:bg-slate-900/90 text-[9px] font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 text-center items-center">
                <div className="col-span-3 text-start ps-1">الصنف / Category</div>
                <div className="col-span-2">Target</div>
                <div className="col-span-2">MTD</div>
                <div className="col-span-2">المتبقي</div>
                <div className="col-span-1">اليومي</div>
                <div className="col-span-2">اليوم ✍️</div>
              </div>

              <div className="divide-y divide-slate-100 dark:divide-slate-800/80">
                {[
                  { key: 'ent_acc', title: '🔹 Ent Acc', label: 'Acc' },
                  { key: 'ent_gas', title: '🔹 Ent GAs', label: 'GAs' },
                ].map(({ key, title }) => {
                  const itm = computedItems[key];
                  return (
                    <div key={key} className="grid grid-cols-12 gap-1 items-center px-2 py-1 text-center hover:bg-slate-500/5 transition-colors">
                      <div className="col-span-3 flex items-center justify-between gap-1 text-start ps-1 overflow-hidden">
                        <span className="font-extrabold text-[11px] truncate text-slate-800 dark:text-slate-100">{title}</span>
                        <div className="flex items-center gap-1">
                          <span className={`px-1 py-0.2 rounded font-mono font-black text-[9px] shrink-0 ${getPercentBadge(itm.mtdPercent)}`}>
                            {formatPercent(itm.mtdPercent)}
                          </span>
                        </div>
                      </div>
                      <div className="col-span-2">
                        <input
                          type="number"
                          min="0"
                          step="1"
                          value={itm.monthlyTarget}
                          onFocus={(e) => e.target.select()}
                          onChange={(e) => handleItemFieldChange(key, 'monthlyTarget', e.target.value)}
                          className={`w-full text-center font-mono font-bold text-xs py-0.5 rounded border ${
                            darkMode ? 'bg-slate-900 border-slate-700 text-white' : 'bg-white border-slate-300 text-slate-900'
                          } focus:border-blue-500 outline-none`}
                          placeholder="0"
                        />
                      </div>
                      <div className="col-span-2">
                        <input
                          type="number"
                          min="0"
                          step="1"
                          value={itm.mtdAchievement}
                          onFocus={(e) => e.target.select()}
                          onChange={(e) => handleItemFieldChange(key, 'mtdAchievement', e.target.value)}
                          className={`w-full text-center font-mono font-black text-xs py-0.5 rounded border ${
                            darkMode ? 'bg-blue-950/60 border-blue-500 text-blue-200' : 'bg-blue-50 border-blue-400 text-blue-950'
                          } focus:border-blue-500 outline-none`}
                          placeholder="0"
                        />
                      </div>
                      <div className="col-span-2">
                        <div className={`w-full font-mono font-black text-xs py-0.5 rounded border ${
                          darkMode ? 'bg-amber-950/40 border-amber-600/70 text-amber-200' : 'bg-amber-50 border-amber-300 text-amber-950'
                        }`}>
                          {formatNumber(itm.remainingTarget)}
                        </div>
                      </div>
                      <div className="col-span-1">
                        <div className={`w-full font-mono font-black text-xs py-0.5 rounded border ${
                          darkMode ? 'bg-emerald-950/40 border-emerald-600/70 text-emerald-200' : 'bg-emerald-50 border-emerald-300 text-emerald-950'
                        }`}>
                          {formatNumber(itm.dailyTarget)}
                        </div>
                      </div>
                      <div className="col-span-2">
                        <input
                          type="number"
                          min="0"
                          step="1"
                          value={itm.todayAch}
                          onFocus={(e) => e.target.select()}
                          onChange={(e) => handleItemFieldChange(key, 'todayAch', e.target.value)}
                          className={`w-full text-center font-mono font-black text-xs py-0.5 rounded border-2 ${
                            darkMode ? 'bg-blue-950/70 border-blue-400 text-blue-100' : 'bg-blue-50 border-blue-500 text-blue-950'
                          } focus:ring-1 focus:ring-blue-400 outline-none`}
                          placeholder="0"
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Enterprise Summary Row */}
              <div className="grid grid-cols-12 gap-1 items-center px-2 py-0.5 bg-blue-500/10 text-center font-black text-[10px] border-t border-blue-500/30">
                <div className="col-span-3 text-start ps-1 text-blue-900 dark:text-blue-200 font-extrabold truncate">
                  إجمالي بوكس Ent
                </div>
                <div className="col-span-2 font-mono font-black">{formatNumber(enterpriseBox.monthlyTarget)}</div>
                <div className="col-span-2 font-mono font-black text-blue-700 dark:text-blue-300">{formatNumber(enterpriseBox.mtdAchievement)}</div>
                <div className="col-span-2 font-mono font-black text-amber-800 dark:text-amber-300">{formatNumber(enterpriseBox.remainingTarget)}</div>
                <div className="col-span-1 font-mono font-black text-emerald-800 dark:text-emerald-300">{formatNumber(enterpriseBox.dailyTarget)}</div>
                <div className="col-span-2 font-mono font-black text-blue-800 dark:text-blue-300">{formatNumber(enterpriseBox.todayAch)}</div>
              </div>
            </div>

            {/* BOX 4: 🌐 Fixed (ADSL 16% + @Home 4%) */}
            <div className={`rounded-xl border-2 overflow-hidden shadow-xs transition-colors ${
              darkMode ? 'bg-[#0E172E] border-indigo-600' : 'bg-white border-indigo-500'
            }`}>
              <div className="flex items-center justify-between px-2.5 py-1.5 bg-indigo-700 text-white text-xs sm:text-sm font-black shadow-xs">
                <span>🌐 Fixed Box (ADSL {boxWeights.adsl}% + @Home {boxWeights.home}%)</span>
                <div className="flex items-center gap-1.5 sm:gap-2 font-mono text-[10px] sm:text-xs">
                  <span>Target: {formatNumber(fixedBox.monthlyTarget)}</span>
                  <span>MTD: {formatNumber(fixedBox.mtdAchievement)}</span>
                  <span className="px-1.5 py-0.5 rounded bg-black/40 text-indigo-200 font-bold" title="MTD %">
                    MTD: {formatPercent(fixedBox.mtdPercent)}
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-emerald-950/80 border border-emerald-400/50 text-emerald-300 font-black" title="Fixed Projection % (حساب منفصل: ADSL + @Home)">
                    RE: {formatPercent(fixedBox.projectionPercent)}
                  </span>
                </div>
              </div>

              {/* Daily Achievement Goal Visualizer */}
              <BoxDailyGoalVisualizer
                boxLabel="Fixed"
                todayAch={fixedBox.todayAch}
                dailyTarget={fixedBox.dailyTarget}
                colorTheme="indigo"
                subChips={[
                  { label: 'ADSL', today: computedItems.adsl.todayAch, target: computedItems.adsl.dailyTarget },
                  { label: '@Home', today: computedItems.home.todayAch, target: computedItems.home.dailyTarget },
                ]}
              />

              {/* Column Headers */}
              <div className="grid grid-cols-12 gap-1 px-2 py-0.5 bg-slate-100 dark:bg-slate-900/90 text-[9px] font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 text-center items-center">
                <div className="col-span-3 text-start ps-1">الصنف / Category</div>
                <div className="col-span-2">Target</div>
                <div className="col-span-2">MTD</div>
                <div className="col-span-2">المتبقي</div>
                <div className="col-span-1">اليومي</div>
                <div className="col-span-2">اليوم ✍️</div>
              </div>

              <div className="divide-y divide-slate-100 dark:divide-slate-800/80">
                {[
                  { key: 'adsl', title: '🔹 ADSL', weight: boxWeights.adsl, projVal: fixedBox.adslProjVal },
                  { key: 'home', title: '🔹 @Home', weight: boxWeights.home, projVal: fixedBox.homeProjVal },
                ].map(({ key, title, weight, projVal }) => {
                  const itm = computedItems[key];
                  return (
                    <div key={key} className="grid grid-cols-12 gap-1 items-center px-2 py-1 text-center hover:bg-slate-500/5 transition-colors">
                      <div className="col-span-3 flex items-center justify-between gap-1 text-start ps-1 overflow-hidden">
                        <span className="font-extrabold text-[11px] truncate text-slate-800 dark:text-slate-100">{title} ({weight}%)</span>
                        <div className="flex items-center gap-1 shrink-0">
                          <span className={`px-1 py-0.2 rounded font-mono font-black text-[9px] ${getPercentBadge(itm.mtdPercent)}`} title="MTD %">
                            {formatPercent(itm.mtdPercent)}
                          </span>
                          <span className="px-1 py-0.2 rounded font-mono font-black text-[9px] bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30" title="Expected / Projection % (RE)">
                            RE: {formatPercent(projVal)}
                          </span>
                        </div>
                      </div>
                      <div className="col-span-2">
                        <input
                          type="number"
                          min="0"
                          step="1"
                          value={itm.monthlyTarget}
                          onFocus={(e) => e.target.select()}
                          onChange={(e) => handleItemFieldChange(key, 'monthlyTarget', e.target.value)}
                          className={`w-full text-center font-mono font-bold text-xs py-0.5 rounded border ${
                            darkMode ? 'bg-slate-900 border-slate-700 text-white' : 'bg-white border-slate-300 text-slate-900'
                          } focus:border-indigo-500 outline-none`}
                          placeholder="0"
                        />
                      </div>
                      <div className="col-span-2">
                        <input
                          type="number"
                          min="0"
                          step="1"
                          value={itm.mtdAchievement}
                          onFocus={(e) => e.target.select()}
                          onChange={(e) => handleItemFieldChange(key, 'mtdAchievement', e.target.value)}
                          className={`w-full text-center font-mono font-black text-xs py-0.5 rounded border ${
                            darkMode ? 'bg-indigo-950/60 border-indigo-500 text-indigo-200' : 'bg-indigo-50 border-indigo-400 text-indigo-950'
                          } focus:border-indigo-500 outline-none`}
                          placeholder="0"
                        />
                      </div>
                      <div className="col-span-2">
                        <div className={`w-full font-mono font-black text-xs py-0.5 rounded border ${
                          darkMode ? 'bg-amber-950/40 border-amber-600/70 text-amber-200' : 'bg-amber-50 border-amber-300 text-amber-950'
                        }`}>
                          {formatNumber(itm.remainingTarget)}
                        </div>
                      </div>
                      <div className="col-span-1">
                        <div className={`w-full font-mono font-black text-xs py-0.5 rounded border ${
                          darkMode ? 'bg-emerald-950/40 border-emerald-600/70 text-emerald-200' : 'bg-emerald-50 border-emerald-300 text-emerald-950'
                        }`}>
                          {formatNumber(itm.dailyTarget)}
                        </div>
                      </div>
                      <div className="col-span-2">
                        <input
                          type="number"
                          min="0"
                          step="1"
                          value={itm.todayAch}
                          onFocus={(e) => e.target.select()}
                          onChange={(e) => handleItemFieldChange(key, 'todayAch', e.target.value)}
                          className={`w-full text-center font-mono font-black text-xs py-0.5 rounded border-2 ${
                            darkMode ? 'bg-blue-950/70 border-blue-400 text-blue-100' : 'bg-blue-50 border-blue-500 text-blue-950'
                          } focus:ring-1 focus:ring-blue-400 outline-none`}
                          placeholder="0"
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Fixed Summary Row */}
              <div className="grid grid-cols-12 gap-1 items-center px-2 py-0.5 bg-indigo-500/10 text-center font-black text-[10px] border-t border-indigo-500/30">
                <div className="col-span-3 text-start ps-1 text-indigo-900 dark:text-indigo-200 font-extrabold truncate flex items-center justify-between">
                  <span>إجمالي بوكس Fixed</span>
                  <span className="text-[9px] font-mono text-emerald-700 dark:text-emerald-300 font-black">
                    RE: {formatPercent(fixedBox.projectionPercent)}
                  </span>
                </div>
                <div className="col-span-2 font-mono font-black">{formatNumber(fixedBox.monthlyTarget)}</div>
                <div className="col-span-2 font-mono font-black text-indigo-700 dark:text-indigo-300">{formatNumber(fixedBox.mtdAchievement)}</div>
                <div className="col-span-2 font-mono font-black text-amber-800 dark:text-amber-300">{formatNumber(fixedBox.remainingTarget)}</div>
                <div className="col-span-1 font-mono font-black text-emerald-800 dark:text-emerald-300">{formatNumber(fixedBox.dailyTarget)}</div>
                <div className="col-span-2 font-mono font-black text-blue-800 dark:text-blue-300">{formatNumber(fixedBox.todayAch)}</div>
              </div>
            </div>

          </div>
        ) : (
          /* COMPACT TABLE VIEW */
          <div className={`w-full rounded-md border shadow-2xs overflow-hidden shrink-0 transition-colors ${
            darkMode ? 'border-slate-700 bg-[#0E172E]' : 'border-slate-300 bg-white'
          }`}>
            <div className="w-full overflow-x-auto">
              <table className="w-full min-w-[700px] table-fixed border-collapse text-center text-[10px] sm:text-xs">
                <thead>
                  <tr className="bg-teal-700 text-white text-[9px] sm:text-[10px]">
                    <th className="py-1 px-1 border-r text-center w-[16%]">Box / Category</th>
                    <th className="py-1 px-0.5 border-r text-center">Target</th>
                    <th className="py-1 px-0.5 border-r text-center">MTD</th>
                    <th className="py-1 px-0.5 border-r text-center">Remaining</th>
                    <th className="py-1 px-0.5 border-r text-center">Daily Target</th>
                    <th className="py-1 px-0.5 border-r text-center">Today Ach</th>
                    <th className="py-1 px-0.5 border-r text-center">MTD %</th>
                    <th className="py-1 px-0.5 text-center">Projection %</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {Object.entries(DEFAULT_ITEMS).map(([k, meta]) => {
                    const itm = computedItems[k];
                    return (
                      <tr key={k} className="hover:bg-slate-500/5">
                        <td className="py-1 px-1 border-r text-left sm:text-center font-bold">
                          {meta.name}
                        </td>
                        <td className="py-0.5 px-0.5 border-r">
                          <input
                            type="number"
                            value={itm.monthlyTarget}
                            onChange={(e) => handleItemFieldChange(k, 'monthlyTarget', e.target.value)}
                            className="w-full text-center font-mono outline-none bg-transparent"
                          />
                        </td>
                        <td className="py-0.5 px-0.5 border-r">
                          <input
                            type="number"
                            value={itm.mtdAchievement}
                            onChange={(e) => handleItemFieldChange(k, 'mtdAchievement', e.target.value)}
                            className="w-full text-center font-mono outline-none bg-transparent text-teal-600 dark:text-teal-400 font-bold"
                          />
                        </td>
                        <td className="py-1 px-0.5 border-r font-mono font-semibold text-amber-600">
                          {formatNumber(itm.remainingTarget)}
                        </td>
                        <td className="py-1 px-0.5 border-r font-mono text-teal-600">
                          {formatNumber(itm.dailyTarget)}
                        </td>
                        <td className="py-0.5 px-0.5 border-r bg-blue-500/10">
                          <input
                            type="number"
                            value={itm.todayAch}
                            onChange={(e) => handleItemFieldChange(k, 'todayAch', e.target.value)}
                            className="w-full text-center font-mono outline-none bg-transparent text-blue-600 font-bold"
                          />
                        </td>
                        <td className="py-1 px-0.5 border-r font-mono">
                          <span className={`px-1 py-0.2 rounded ${getPercentBadge(itm.mtdPercent)}`}>
                            {formatPercent(itm.mtdPercent)}
                          </span>
                        </td>
                        <td className="py-1 px-0.5 font-mono">
                          {formatPercent(itm.projectionPercent)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* 7-DAY DAILY ACHIEVEMENTS TREND CHART (RECHARTS) */}
        <div className={`rounded-xl border-2 p-2 transition-colors shrink-0 shadow-xs ${
          darkMode ? 'bg-[#0E172E] border-slate-700' : 'bg-white border-slate-300'
        }`}>
          {/* Chart Header */}
          <div className="flex flex-wrap items-center justify-between gap-1 mb-1.5 pb-1 border-b border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-1.5">
              <div className="p-1 rounded bg-teal-600 text-white">
                <BarChart3 className="w-3.5 h-3.5" />
              </div>
              <div>
                <h2 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                  <span>منحنى الإنجاز اليومي لآخر 7 أيام</span>
                  <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-teal-500/20 text-teal-600 dark:text-teal-400 font-bold border border-teal-500/30">
                    7-Day Trend
                  </span>
                </h2>
                <span className="text-[9px] text-slate-500 dark:text-slate-400">
                  تتبع حركة الإنجاز اليومي التراكمي ومقارنته بالمستهدف
                </span>
              </div>
            </div>

            {/* Quick Metrics & View Mode Toggle */}
            <div className="flex items-center gap-1 text-[9px]">
              <div className="hidden sm:flex items-center gap-1">
                <span className="px-1.5 py-0.5 rounded bg-teal-500/10 text-teal-700 dark:text-teal-300 font-bold border border-teal-500/20">
                  إجمالي 7 أيام: <strong className="font-mono font-black">{formatNumber(chartMetrics.totalSum)}</strong>
                </span>
                <span className="px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-700 dark:text-blue-300 font-bold border border-blue-500/20">
                  متوسط يومي: <strong className="font-mono font-black">{formatNumber(chartMetrics.avgDaily)}</strong>
                </span>
                <span className="px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 font-bold border border-emerald-500/20">
                  إنجاز اليوم: <strong className="font-mono font-black">{formatNumber(chartMetrics.todayTotal)}</strong>
                </span>
              </div>

              {/* Toggle Total vs Breakdown */}
              <div className="flex items-center p-0.5 rounded border border-slate-300 dark:border-slate-700 bg-slate-100 dark:bg-slate-800">
                <button
                  onClick={() => setChartMode('total')}
                  className={`px-2 py-0.5 rounded text-[9px] font-bold cursor-pointer transition-all ${
                    chartMode === 'total'
                      ? 'bg-teal-600 text-white shadow-2xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                  }`}
                >
                  الإجمالي
                </button>
                <button
                  onClick={() => setChartMode('breakdown')}
                  className={`px-2 py-0.5 rounded text-[9px] font-bold cursor-pointer transition-all ${
                    chartMode === 'breakdown'
                      ? 'bg-teal-600 text-white shadow-2xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                  }`}
                >
                  تفصيل البوكسات
                </button>
              </div>
            </div>
          </div>

          {/* Recharts Area Container */}
          <div className="w-full h-40 sm:h-48">
            <ResponsiveContainer width="100%" height="100%">
              {chartMode === 'total' ? (
                <AreaChart data={active7DayData} margin={{ top: 8, right: 8, left: -22, bottom: 0 }}>
                  <defs>
                    <linearGradient id="totalGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#0d9488" stopOpacity={0.5} />
                      <stop offset="95%" stopColor="#0d9488" stopOpacity={0.0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke={darkMode ? '#1e293b' : '#e2e8f0'} />
                  <XAxis 
                    dataKey="date" 
                    tick={{ fontSize: 9, fill: darkMode ? '#94a3b8' : '#64748b', fontWeight: 600 }}
                    stroke={darkMode ? '#334155' : '#cbd5e1'}
                  />
                  <YAxis 
                    tick={{ fontSize: 9, fill: darkMode ? '#94a3b8' : '#64748b', fontWeight: 600 }}
                    stroke={darkMode ? '#334155' : '#cbd5e1'}
                    allowDecimals={false}
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload as DailyTrendPoint;
                        return (
                          <div className={`p-2 rounded-md shadow-lg border text-xs ${
                            darkMode ? 'bg-slate-900 border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-900'
                          }`}>
                            <p className="font-bold border-b pb-1 mb-1 border-slate-200 dark:border-slate-800 text-teal-600 dark:text-teal-400">
                              {data.dayLabel}
                            </p>
                            <p className="font-mono font-black text-sm text-teal-700 dark:text-teal-300">
                              إجمالي الإنجاز: {formatNumber(data.total)}
                            </p>
                            <div className="grid grid-cols-2 gap-x-2 gap-y-0.5 mt-1 text-[10px] text-slate-500 dark:text-slate-400">
                              <span>Acq: {formatNumber(data.acq)}</span>
                              <span>Ter: {formatNumber(data.terminal)}</span>
                              <span>Ent: {formatNumber(data.enterprise)}</span>
                              <span>Fixed: {formatNumber(data.fixed)}</span>
                            </div>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="total"
                    stroke="#0d9488"
                    strokeWidth={2.5}
                    fillOpacity={1}
                    fill="url(#totalGradient)"
                    dot={{ r: 3, fill: '#0d9488', strokeWidth: 1, stroke: '#fff' }}
                    activeDot={{ r: 5, fill: '#0f766e', stroke: '#fff', strokeWidth: 2 }}
                    name="الإجمالي اليومي"
                  />
                </AreaChart>
              ) : (
                <AreaChart data={active7DayData} margin={{ top: 8, right: 8, left: -22, bottom: 0 }}>
                  <defs>
                    <linearGradient id="acqGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#0d9488" stopOpacity={0.5} />
                      <stop offset="95%" stopColor="#0d9488" stopOpacity={0.0} />
                    </linearGradient>
                    <linearGradient id="terGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#0284c7" stopOpacity={0.5} />
                      <stop offset="95%" stopColor="#0284c7" stopOpacity={0.0} />
                    </linearGradient>
                    <linearGradient id="entGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#2563eb" stopOpacity={0.5} />
                      <stop offset="95%" stopColor="#2563eb" stopOpacity={0.0} />
                    </linearGradient>
                    <linearGradient id="fixGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#6366f1" stopOpacity={0.5} />
                      <stop offset="95%" stopColor="#6366f1" stopOpacity={0.0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke={darkMode ? '#1e293b' : '#e2e8f0'} />
                  <XAxis 
                    dataKey="date" 
                    tick={{ fontSize: 9, fill: darkMode ? '#94a3b8' : '#64748b', fontWeight: 600 }}
                    stroke={darkMode ? '#334155' : '#cbd5e1'}
                  />
                  <YAxis 
                    tick={{ fontSize: 9, fill: darkMode ? '#94a3b8' : '#64748b', fontWeight: 600 }}
                    stroke={darkMode ? '#334155' : '#cbd5e1'}
                    allowDecimals={false}
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload as DailyTrendPoint;
                        return (
                          <div className={`p-2 rounded-md shadow-lg border text-xs ${
                            darkMode ? 'bg-slate-900 border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-900'
                          }`}>
                            <p className="font-bold border-b pb-1 mb-1 border-slate-200 dark:border-slate-800 text-teal-600 dark:text-teal-400">
                              {data.dayLabel}
                            </p>
                            <div className="space-y-0.5 font-mono text-[11px] font-bold">
                              <p className="text-teal-600 dark:text-teal-400">Acquisition: {formatNumber(data.acq)}</p>
                              <p className="text-sky-600 dark:text-sky-400">Terminal: {formatNumber(data.terminal)}</p>
                              <p className="text-blue-600 dark:text-blue-400">Enterprise: {formatNumber(data.enterprise)}</p>
                              <p className="text-indigo-600 dark:text-indigo-400">Fixed: {formatNumber(data.fixed)}</p>
                              <p className="border-t pt-0.5 text-slate-900 dark:text-white font-black">
                                الإجمالي: {formatNumber(data.total)}
                              </p>
                            </div>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Legend 
                    wrapperStyle={{ fontSize: '9px', paddingTop: '2px' }}
                    iconSize={7}
                  />
                  <Area type="monotone" dataKey="acq" name="Acq" stroke="#0d9488" fillOpacity={1} fill="url(#acqGrad)" strokeWidth={2} />
                  <Area type="monotone" dataKey="terminal" name="Terminal" stroke="#0284c7" fillOpacity={1} fill="url(#terGrad)" strokeWidth={2} />
                  <Area type="monotone" dataKey="enterprise" name="Enterprise" stroke="#2563eb" fillOpacity={1} fill="url(#entGrad)" strokeWidth={2} />
                  <Area type="monotone" dataKey="fixed" name="Fixed" stroke="#6366f1" fillOpacity={1} fill="url(#fixGrad)" strokeWidth={2} />
                </AreaChart>
              )}
            </ResponsiveContainer>
          </div>
        </div>

        {/* Strengths & Weaknesses Container (High-Contrast, Space-Optimized) */}
        <div className={`rounded-lg border-2 p-1.5 sm:p-2 transition-colors shrink-0 shadow-xs ${
          darkMode ? 'bg-[#0E172E] border-slate-700' : 'bg-white border-slate-300'
        }`}>
          <div className="flex items-center justify-between mb-1 pb-1 border-b border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
              <h2 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white">
                تحليل الأداء والمتوقع (نقاط القوة والضعف)
              </h2>
            </div>
            <span className="text-[9px] font-bold text-slate-500 dark:text-slate-400">
              بناءً على نسبة المتوقع (Projection %) لكل بوكس
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-xs">
            {/* Strengths */}
            <div className={`rounded-md p-1.5 border-2 ${
              darkMode ? 'bg-emerald-950/80 border-emerald-500' : 'bg-emerald-50 border-emerald-500 shadow-2xs'
            }`}>
              <div className="flex items-center gap-1.5 mb-1 font-black text-[11px] text-emerald-900 dark:text-emerald-200">
                <TrendingUp className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span>نقاط القوة (فوق 100%)</span>
              </div>
              {analysisInsights.strengths.length > 0 ? (
                <div className="flex flex-wrap gap-1">
                  {analysisInsights.strengths.map((item) => (
                    <div 
                      key={item.name} 
                      className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-emerald-700 text-white font-mono text-[11px] font-bold shadow-2xs"
                    >
                      <span className="font-extrabold font-sans">{item.name}:</span>
                      <span className="font-black text-emerald-100">{item.proj}%</span>
                      <span className="text-[9px] bg-emerald-900/60 px-1 rounded text-emerald-200">
                        +{item.diff}%
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-[10px] text-slate-500 dark:text-slate-400 italic">
                  لا توجد فئات تجاوزت 100% متوقع حتى الآن
                </p>
              )}
            </div>

            {/* Weaknesses */}
            <div className={`rounded-md p-1.5 border-2 ${
              darkMode ? 'bg-rose-950/80 border-rose-500' : 'bg-rose-50 border-rose-500 shadow-2xs'
            }`}>
              <div className="flex items-center gap-1.5 mb-1 font-black text-[11px] text-rose-900 dark:text-rose-200">
                <TrendingDown className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
                <span>نقاط الضعف والمتابعة (أقل من 85%)</span>
              </div>
              {analysisInsights.weaknesses.length > 0 ? (
                <div className="flex flex-wrap gap-1">
                  {analysisInsights.weaknesses.map((item) => (
                    <div 
                      key={item.name} 
                      className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-rose-700 text-white font-mono text-[11px] font-bold shadow-2xs"
                    >
                      <span className="font-extrabold font-sans">{item.name}:</span>
                      <span className="font-black text-rose-100">{item.proj}%</span>
                      <span className="text-[9px] bg-rose-900/60 px-1 rounded text-rose-200">
                        عجز -{item.diff}%
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-[10px] font-bold text-emerald-700 dark:text-emerald-300">
                  ممتاز! لا توجد فجوات حرجة أو متأخرة في التارجت 🎉
                </p>
              )}
            </div>
          </div>
        </div>

        {/* tNPS Calculator Section - High Contrast Table */}
        <div className={`border-2 rounded-lg overflow-hidden shadow-xs transition-colors shrink-0 ${
          darkMode ? 'border-red-900/80 bg-[#0E172E]' : 'border-red-300 bg-white'
        }`}>
          <div className="flex items-center justify-between px-2.5 py-1 bg-[#8B0000] text-white shadow-xs">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-black uppercase tracking-wider">
                tNPS Calculator
              </span>
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-black/40 text-red-100 border border-red-400/40 font-mono font-bold">
                Target: 70%
              </span>
            </div>
            <button
              onClick={() => setTnpsRows(SAMPLE_TNPS_ROWS)}
              className="text-[10px] underline text-red-100 hover:text-white font-bold cursor-pointer"
            >
              Load Sample (62%)
            </button>
          </div>

          <div className="w-full overflow-x-auto">
            <table className="w-full table-fixed border-collapse text-center">
              <thead>
                <tr className="bg-[#8B0000] text-white text-[9px] sm:text-[10px] font-black border-b border-red-950">
                  <th className="py-0.5 px-1 w-[20%] border-r border-red-900 text-center">Agent Name</th>
                  <th className="py-0.5 px-0.5 w-[11%] border-r border-red-900 text-center">Detractors</th>
                  <th className="py-0.5 px-0.5 w-[11%] border-r border-red-900 text-center">Passive</th>
                  <th className="py-0.5 px-0.5 w-[11%] border-r border-red-900 text-center">Promoters</th>
                  <th className="py-0.5 px-0.5 w-[11%] border-r border-red-900 text-center">Total</th>
                  <th className="py-0.5 px-0.5 w-[13%] border-r border-red-900 text-center">Final TNPS %</th>
                  <th className="py-0.5 px-0.5 w-[13%] border-r border-red-900 text-center">Required Promoters</th>
                  <th className="py-0.5 px-0.5 w-[10%] text-center">Daily</th>
                </tr>
              </thead>
              <tbody className={`divide-y text-xs text-center ${darkMode ? 'divide-slate-800' : 'divide-slate-200'}`}>
                {computedTnpsRows.map((row, idx) => {
                  const isSuccess = row.tnpsPercent >= 70;
                  return (
                    <tr key={row.id}>
                      <td className="py-0.5 px-1 border-r text-center">
                        <input
                          type="text"
                          value={row.agentName}
                          onChange={(e) => handleTnpsChange(idx, 'agentName', e.target.value)}
                          placeholder="Agent Name"
                          className="w-full text-center font-bold outline-none bg-transparent"
                        />
                      </td>
                      <td className="py-0.5 px-0.5 border-r text-center">
                        <input
                          type="number"
                          min="0"
                          value={row.detractors}
                          onChange={(e) => handleTnpsChange(idx, 'detractors', e.target.value)}
                          className="w-full text-center font-mono font-black outline-none bg-transparent text-amber-700 dark:text-amber-300"
                        />
                      </td>
                      <td className="py-1 px-0.5 border-r text-center">
                        <input
                          type="number"
                          min="0"
                          value={row.passive}
                          onChange={(e) => handleTnpsChange(idx, 'passive', e.target.value)}
                          className="w-full text-center font-mono font-black outline-none bg-transparent text-amber-700 dark:text-amber-300"
                        />
                      </td>
                      <td className="py-1 px-0.5 border-r text-center">
                        <input
                          type="number"
                          min="0"
                          value={row.promoters}
                          onChange={(e) => handleTnpsChange(idx, 'promoters', e.target.value)}
                          className="w-full text-center font-mono font-black outline-none bg-transparent text-amber-700 dark:text-amber-300"
                        />
                      </td>
                      <td className="py-1 px-0.5 border-r font-mono font-black text-slate-900 dark:text-white">
                        {formatNumber(row.total)}
                      </td>
                      <td className="py-1 px-0.5 border-r text-center">
                        <div className={`rounded font-mono font-black py-1 text-white shadow-2xs ${
                          row.total === 0 ? 'bg-red-800' : isSuccess ? 'bg-[#15803D]' : 'bg-[#DC2626]'
                        }`}>
                          {formatPercent(row.tnpsPercent)}
                        </div>
                      </td>
                      <td className="py-1 px-0.5 border-r text-center">
                        <div className="rounded font-mono font-black py-1 text-white bg-[#15803D] shadow-2xs">
                          {formatNumber(row.requiredPromoters)}
                        </div>
                      </td>
                      <td className="py-1 px-0.5 text-center font-mono font-black text-slate-900 dark:text-white">
                        {formatNumber(row.daily)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Compact Footer */}
        <div className={`text-[9px] px-1 flex items-center justify-between shrink-0 transition-colors ${
          darkMode ? 'text-slate-400' : 'text-slate-600'
        }`}>
          <span className="font-normal">
            © 2026 created by Ahmed Sobhy
          </span>
          <button
            onClick={handleLoadTestPreset}
            className={`underline cursor-pointer ${
              darkMode ? 'text-teal-400 hover:text-teal-300' : 'text-teal-700 hover:text-teal-900'
            }`}
          >
            Load Store Test Sample
          </button>
        </div>
      </div>

      {/* WhatsApp Modal with Preview & Send */}
      {showWhatsAppModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-2xs p-3">
          <div className={`rounded-lg shadow-xl max-w-md w-full p-3 border animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[90vh] ${
            darkMode ? 'bg-[#111C38] border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-900'
          }`}>
            <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-1.5">
                <div className="p-1 rounded bg-emerald-600 text-white">
                  <MessageSquare className="w-3.5 h-3.5" />
                </div>
                <h3 className="text-xs font-bold">تقرير الواتساب اليومي (Store Daily)</h3>
              </div>
              <button
                onClick={() => setShowWhatsAppModal(false)}
                className={`rounded p-1 cursor-pointer ${darkMode ? 'text-slate-400 hover:text-white' : 'text-slate-400 hover:text-slate-600'}`}
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Red Sales input */}
            <div className="grid grid-cols-2 gap-1.5 my-2 p-1.5 rounded bg-slate-500/10 text-[10px]">
              <div>
                <label className="block text-[8px] text-slate-400 font-medium mb-0.5">
                  Red Sales (Today)
                </label>
                <input
                  type="number"
                  min="0"
                  value={redSalesToday}
                  onChange={(e) => setRedSalesToday(e.target.value)}
                  className={`w-full p-1 rounded border font-mono text-[10px] outline-none ${
                    darkMode ? 'bg-slate-900 border-slate-700 text-white' : 'bg-white border-slate-300 text-slate-900'
                  }`}
                  placeholder="0"
                />
              </div>
              <div>
                <label className="block text-[8px] text-slate-400 font-medium mb-0.5">
                  Red Sales (Target)
                </label>
                <input
                  type="number"
                  min="0"
                  value={redSalesTarget}
                  onChange={(e) => setRedSalesTarget(e.target.value)}
                  className={`w-full p-1 rounded border font-mono text-[10px] outline-none ${
                    darkMode ? 'bg-slate-900 border-slate-700 text-white' : 'bg-white border-slate-300 text-slate-900'
                  }`}
                  placeholder="0 (0 يحذفها من الرسالة)"
                />
              </div>
            </div>

            {/* Message Preview */}
            <div className="flex-1 overflow-y-auto my-1 border rounded p-2 font-mono text-[10px] whitespace-pre-wrap leading-relaxed select-all bg-slate-950 text-emerald-300 border-slate-800">
              {generateWhatsAppMessage()}
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-200 dark:border-slate-800 gap-1.5">
              <button
                onClick={handleCopyWhatsApp}
                className="inline-flex items-center gap-1 px-3 py-1 text-[10px] font-semibold border rounded cursor-pointer transition-colors hover:bg-slate-500/10"
              >
                {copiedWhatsApp ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                <span>{copiedWhatsApp ? 'تم النسخ!' : 'نسخ الرسالة'}</span>
              </button>

              <div className="flex items-center gap-1.5">
                <a
                  href={whatsappShareUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1 text-[10px] font-bold rounded bg-emerald-600 hover:bg-emerald-500 text-white shadow-sm cursor-pointer transition-all active:scale-95"
                >
                  <Send className="w-3 h-3" />
                  <span>فتح في واتساب 📱</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Reset Modal */}
      {showResetModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-2xs p-3">
          <div className={`rounded-lg shadow-xl max-w-xs w-full p-3 border animate-in fade-in zoom-in-95 duration-150 ${
            darkMode ? 'bg-[#111C38] border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-900'
          }`}>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                <h3 className="text-xs font-bold">Reset Options</h3>
              </div>
              <button
                onClick={() => setShowResetModal(false)}
                className={`rounded p-1 cursor-pointer ${darkMode ? 'text-slate-400 hover:text-white' : 'text-slate-400 hover:text-slate-600'}`}
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="flex flex-col gap-1.5 mb-2.5">
              <button
                onClick={handleResetTodayOnly}
                className={`w-full py-1 px-2 text-[10px] border rounded transition-colors text-left flex items-center justify-between cursor-pointer ${
                  darkMode ? 'bg-amber-950/40 hover:bg-amber-950/70 border-amber-800 text-amber-300' : 'bg-amber-50 hover:bg-amber-100 border-amber-300 text-amber-900'
                }`}
              >
                <div>
                  <div className="font-bold flex items-center gap-1">
                    <span>تصفير اليومي فقط (لبدء شفت جديد) 🌅</span>
                  </div>
                  <div className={`text-[8px] ${darkMode ? 'text-amber-400' : 'text-amber-700'}`}>
                    تصفير خانات اليوم فقط مع الاحتفاظ بالتارجت و MTD الحالي
                  </div>
                </div>
                <ChevronRight className="w-3 h-3 text-amber-400" />
              </button>

              <button
                onClick={handleLoadStandardDemo}
                className={`w-full py-1 px-2 text-[10px] border rounded transition-colors text-left flex items-center justify-between cursor-pointer ${
                  darkMode ? 'bg-slate-800 hover:bg-slate-700 border-slate-600 text-slate-100' : 'bg-slate-50 hover:bg-slate-100 border-slate-300 text-slate-900'
                }`}
              >
                <div>
                  <div className="font-bold">Standard Store Demo (0 Targets)</div>
                  <div className={`text-[8px] ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                    Targets at 0, default box weights: 60/10/10/16/4
                  </div>
                </div>
                <ChevronRight className="w-3 h-3 text-slate-400" />
              </button>

              <button
                onClick={handleLoadTestPreset}
                className={`w-full py-1 px-2 text-[10px] border rounded transition-colors text-left flex items-center justify-between cursor-pointer ${
                  darkMode ? 'bg-teal-950/50 hover:bg-teal-950/80 border-teal-800 text-teal-300' : 'bg-teal-50 hover:bg-teal-100 border-teal-200 text-teal-800'
                }`}
              >
                <div>
                  <div className="font-bold">Store Test Sample</div>
                  <div className={`text-[8px] ${darkMode ? 'text-teal-400' : 'text-teal-600'}`}>
                    Realistic test data to preview WhatsApp message
                  </div>
                </div>
                <ChevronRight className="w-3 h-3 text-teal-400" />
              </button>

              <button
                onClick={handleClearAll}
                className={`w-full py-1 px-2 text-[10px] border rounded transition-colors text-left flex items-center justify-between cursor-pointer ${
                  darkMode ? 'bg-rose-950/50 hover:bg-rose-950/80 border-rose-800 text-rose-300' : 'bg-rose-50 hover:bg-rose-100 border-rose-200 text-rose-700'
                }`}
              >
                <div>
                  <div className="font-bold">Clear All Fields to 0</div>
                  <div className={`text-[8px] ${darkMode ? 'text-rose-400' : 'text-rose-600'}`}>Zero out all targets and achievements</div>
                </div>
                <ChevronRight className="w-3 h-3 text-rose-400" />
              </button>
            </div>

            <div className={`flex justify-end pt-1.5 border-t ${darkMode ? 'border-slate-800' : 'border-slate-100'}`}>
              <button
                onClick={() => setShowResetModal(false)}
                className={`px-2 py-0.5 text-[9px] rounded cursor-pointer ${
                  darkMode ? 'bg-slate-800 hover:bg-slate-700 text-slate-200' : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Share Modal */}
      {showShareModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-2xs p-3">
          <div className={`rounded-lg shadow-xl max-w-sm w-full p-3 border animate-in fade-in zoom-in-95 duration-150 ${
            darkMode ? 'bg-[#111C38] border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-900'
          }`}>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5">
                <Share2 className="w-3.5 h-3.5 text-teal-500" />
                <h3 className="text-xs font-bold">Public Shareable Link</h3>
              </div>
              <button
                onClick={() => setShowShareModal(false)}
                className={`rounded p-1 cursor-pointer ${darkMode ? 'text-slate-400 hover:text-white' : 'text-slate-400 hover:text-slate-600'}`}
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="flex items-center gap-1 mb-2">
              <input
                type="text"
                readOnly
                value={window.location.href}
                className={`flex-1 border text-[9px] font-mono py-0.5 px-1.5 rounded select-all outline-none ${
                  darkMode ? 'bg-[#0F172A] border-slate-700 text-slate-200' : 'bg-slate-50 border-slate-300 text-slate-700'
                }`}
              />
              <button
                onClick={copyShareUrl}
                className="inline-flex items-center gap-0.5 px-2 py-0.5 text-[9px] font-semibold text-white bg-teal-600 hover:bg-teal-500 rounded transition-colors cursor-pointer shrink-0"
              >
                {copied ? <Check className="w-2.5 h-2.5" /> : <Copy className="w-2.5 h-2.5" />}
                {copied ? 'Copied' : 'Copy'}
              </button>
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => setShowShareModal(false)}
                className={`px-2 py-0.5 text-[9px] rounded cursor-pointer ${
                  darkMode ? 'bg-slate-800 hover:bg-slate-700 text-slate-200' : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
